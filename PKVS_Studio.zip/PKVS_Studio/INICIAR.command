#!/bin/bash
# PKVS Studio (Mac) - instala o script no REAPER e abre o REAPER com o painel.
export PATH="/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
cd "$(dirname "$0")" || exit 1
AQUI="$(pwd)"
clear
echo "=============================="
echo "   PKVS Studio - Iniciar (Mac)"
echo "=============================="
echo

falhar() { echo; echo "$1"; echo; read -n 1 -s -r -p "Aperte qualquer tecla para fechar..."; echo; exit 1; }

# tira o aviso de "arquivo baixado da internet" dos arquivos do PKVS Studio
xattr -dr com.apple.quarantine "$AQUI" 2>/dev/null

LUA="$AQUI/VS_Estudio_Henzo_Rodrigues.lua"
[ -f "$LUA" ] || falhar "Nao achei o arquivo VS_Estudio_Henzo_Rodrigues.lua. Extraia o ZIP inteiro antes de abrir o INICIAR."
[ -f "$AQUI/LICENCA.sh" ] || falhar "Nao achei o arquivo LICENCA.sh. Extraia o ZIP inteiro antes de abrir o INICIAR."

# 1) instala o script na pasta do REAPER
SCRIPTS="$HOME/Library/Application Support/REAPER/Scripts"
mkdir -p "$SCRIPTS" || falhar "Nao consegui criar a pasta de scripts do REAPER."
cp -f "$LUA" "$SCRIPTS/" || falhar "Nao consegui copiar o script para o REAPER."
cp -f "$AQUI/LICENCA.sh" "$SCRIPTS/"
[ -f "$AQUI/SELECIONAR_PASTAS.sh" ] && cp -f "$AQUI/SELECIONAR_PASTAS.sh" "$SCRIPTS/"
[ -f "$AQUI/pk_bolinha.png" ] && cp -f "$AQUI/pk_bolinha.png" "$SCRIPTS/"
xattr -dr com.apple.quarantine "$SCRIPTS" 2>/dev/null
DESTINO="$SCRIPTS/VS_Estudio_Henzo_Rodrigues.lua"
echo "Script instalado."

# 2) acha o REAPER
achar_reaper() {
  local c
  for c in "/Applications/REAPER.app" "/Applications/REAPER64.app" "/Applications/REAPER (x64).app" \
           "$HOME/Applications/REAPER.app" "$HOME/Applications/REAPER64.app"; do
    [ -d "$c" ] && { echo "$c"; return 0; }
  done
  c=$(mdfind "kMDItemCFBundleIdentifier == 'com.cockos.reaper'" 2>/dev/null | head -n1)
  [ -n "$c" ] && [ -d "$c" ] && { echo "$c"; return 0; }
  return 1
}
APP="$(achar_reaper)"
if [ -z "$APP" ]; then
  APP=$(osascript -e 'POSIX path of (choose file of type {"app"} with prompt "Nao achei o REAPER. Selecione o aplicativo REAPER" default location (POSIX file "/Applications"))' 2>/dev/null | sed -e 's:/*$::')
  [ -n "$APP" ] && [ -d "$APP" ] || falhar "REAPER nao encontrado. Instale o REAPER (reaper.fm) e abra o INICIAR de novo."
fi
echo "REAPER: $APP"

# 3) abre o REAPER ja rodando o script
if pgrep -x "REAPER" >/dev/null 2>&1; then
  echo
  echo "O REAPER ja esta aberto. Para o painel abrir:"
  echo "  1. No REAPER: Actions > Show action list (ou aperte ?)"
  echo "  2. Clique em New action > Load ReaScript..."
  echo "  3. Escolha VS_Estudio_Henzo_Rodrigues.lua (vou abrir a pasta pra voce)"
  echo "  4. Na lista, procure por VS, selecione e clique em Run."
  echo "Dica: se fechar o REAPER e abrir este INICIAR de novo, o painel abre sozinho."
  open "$SCRIPTS"
else
  open -a "$APP" --args "$DESTINO"
  echo
  echo "Abrindo o REAPER... o painel do PKVS Studio vai aparecer."
  echo "Se o painel nao abrir sozinho, faca assim (so uma vez):"
  echo "  Actions > Show action list > New action > Load ReaScript..."
  echo "  e escolha: $DESTINO"
fi
sleep 3
