#!/bin/bash
# PKVS Studio (Mac) - verificacao de licenca (key)
# Chamado pelo script do REAPER, em segundo plano. Nao precisa de senha de administrador.
# Escreve o resultado em um arquivo (-Saida), uma informacao por linha:
#   resultado=ok | recusada | rede | erro
#   motivo=invalida | revogada | outro_pc | expirada | dados_invalidos   (quando recusada)
#   plano=... expira_em=<milissegundos> dias=... maquina=<id do computador>
export PATH="/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

chave=""; saida=""; servidor="https://pkvs-keys.pkvs-studio.workers.dev"; espera=8
while [ $# -gt 0 ]; do
  case "$1" in
    -Chave)    chave="$2"; shift 2 ;;
    -Saida)    saida="$2"; shift 2 ;;
    -Servidor) servidor="$2"; shift 2 ;;
    -Espera)   espera="$2"; shift 2 ;;
    *)         shift ;;
  esac
done

dados="$HOME/Library/Application Support/VS_Estudio_Henzo"
[ -z "$saida" ] && saida="$dados/licenca_resp.txt"
mkdir -p "$(dirname "$saida")" 2>/dev/null

# grava em arquivo temporario e renomeia, para o REAPER nunca ler o arquivo pela metade
gravar() {
  printf '%s\n' "$@" > "$saida.tmp" 2>/dev/null && mv -f "$saida.tmp" "$saida"
}

# ID estavel deste computador: hash do UUID da maquina (o UUID em si nao sai do Mac)
obter_id() {
  local guid=""
  if command -v ioreg >/dev/null 2>&1; then
    guid=$(ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}')
  fi
  if [ -z "$guid" ] && [ -r /etc/machine-id ]; then guid=$(cat /etc/machine-id); fi   # so para testes fora do Mac
  [ -z "$guid" ] && return 1
  guid=$(printf '%s' "$guid" | tr 'A-Z' 'a-z')
  if command -v shasum >/dev/null 2>&1; then
    printf 'PKVS-STUDIO|%s' "$guid" | shasum -a 256 | cut -c1-32
  else
    printf 'PKVS-STUDIO|%s' "$guid" | sha256sum | cut -c1-32
  fi
}

# a key so pode ter letras, numeros e hifen (evita qualquer coisa estranha)
chave_limpa=$(printf '%s' "$chave" | tr 'a-z' 'A-Z' | tr -cd 'A-Z0-9-')
id=$(obter_id)
if [ -z "$id" ]; then
  gravar 'resultado=erro' 'motivo=sem_id' 'maquina='
  exit 0
fi

corpo="{\"chave\":\"$chave_limpa\",\"maquina\":\"$id\"}"
resp=$(curl -sS --connect-timeout "$espera" --max-time "$espera" -X POST \
  -H 'Content-Type: application/json; charset=utf-8' -A 'PKVS-Studio' \
  --data "$corpo" "$servidor/validar" 2>/dev/null | tr -d '\r\n')

# sem resposta, ou resposta que nao e JSON (ex.: pagina de erro): trata como "sem rede"
case "$resp" in
  "{"*) ;;
  *) gravar 'resultado=rede' 'motivo=sem_resposta' "maquina=$id"; exit 0 ;;
esac

campo_txt() { printf '%s' "$resp" | sed -n -E 's/.*"'"$1"'" *: *"([^"]*)".*/\1/p' | head -n1; }
campo_num() { printf '%s' "$resp" | sed -n -E 's/.*"'"$1"'" *: *"?(-?[0-9]+).*/\1/p' | head -n1; }

if printf '%s' "$resp" | grep -Eq '"ok" *: *true'; then
  plano=$(campo_txt plano)
  exp=$(campo_num expira_em)
  dias=$(campo_num dias_restantes)
  gravar 'resultado=ok' "plano=$plano" "expira_em=${exp:-0}" "dias=${dias:-0}" "maquina=$id"
else
  motivo=$(campo_txt motivo)
  [ -z "$motivo" ] && motivo="invalida"
  gravar 'resultado=recusada' "motivo=$motivo" "maquina=$id"
fi
exit 0
