﻿$ErrorActionPreference = 'Stop'
$aqui    = Split-Path -Parent $MyInvocation.MyCommand.Path
$origem  = Join-Path $aqui 'VS_Estudio_Henzo_Rodrigues.lua'
$dados   = Join-Path $env:APPDATA 'VS_Estudio_Henzo'
$arqPath = Join-Path $dados 'reaper_path.txt'

function Falhar($msg) { Write-Host ''; Write-Host $msg -ForegroundColor Yellow; exit 1 }

if (-not (Test-Path $origem)) { Falhar 'Nao achei o arquivo VS_Estudio_Henzo_Rodrigues.lua. Extraia o ZIP inteiro antes de abrir o INICIAR.' }

# 1) instala o script na pasta do REAPER
$scripts = Join-Path $env:APPDATA 'REAPER\Scripts'
New-Item -ItemType Directory -Force -Path $scripts | Out-Null
$destino = Join-Path $scripts 'VS_Estudio_Henzo_Rodrigues.lua'
Copy-Item $origem $destino -Force
$imgOrigem = Join-Path $aqui 'pk_bolinha.png'
if (Test-Path $imgOrigem) { Copy-Item $imgOrigem (Join-Path $scripts 'pk_bolinha.png') -Force }
$bolOrigem = Join-Path $aqui 'BOLINHA.ps1'
if (Test-Path $bolOrigem) { Copy-Item $bolOrigem (Join-Path $scripts 'BOLINHA.ps1') -Force }
$licOrigem = Join-Path $aqui 'LICENCA.ps1'
if (Test-Path $licOrigem) { Copy-Item $licOrigem (Join-Path $scripts 'LICENCA.ps1') -Force } else { Falhar 'Nao achei o arquivo LICENCA.ps1. Extraia o ZIP inteiro antes de abrir o INICIAR.' }
$pastasOrigem = Join-Path $aqui 'SELECIONAR_PASTAS.ps1'
if (Test-Path $pastasOrigem) { Copy-Item $pastasOrigem (Join-Path $scripts 'SELECIONAR_PASTAS.ps1') -Force }
Write-Host 'Script instalado.'

# 2) acha o REAPER
function Achar-Reaper {
  if (Test-Path $arqPath) {
    $p = (Get-Content $arqPath -Raw -Encoding UTF8).Trim()
    if ($p -and (Test-Path $p)) { return $p }
  }
  $c = @("$env:ProgramFiles\REAPER (x64)\reaper.exe", "$env:ProgramFiles\REAPER\reaper.exe", "${env:ProgramFiles(x86)}\REAPER (x64)\reaper.exe", "${env:ProgramFiles(x86)}\REAPER\reaper.exe")
  foreach ($x in $c) { if (Test-Path $x) { return $x } }
  $chaves = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
  foreach ($k in $chaves) {
    $it = Get-ItemProperty $k -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like 'REAPER*' -and $_.InstallLocation }
    foreach ($i in $it) { $x = Join-Path $i.InstallLocation 'reaper.exe'; if (Test-Path $x) { return $x } }
  }
  return $null
}
$exe = Achar-Reaper
if (-not $exe) {
  Add-Type -AssemblyName System.Windows.Forms
  $dlg = New-Object System.Windows.Forms.OpenFileDialog
  $dlg.Title = 'Nao achei o REAPER. Selecione o arquivo reaper.exe'
  $dlg.Filter = 'reaper.exe|reaper.exe'
  if ($dlg.ShowDialog() -eq 'OK') {
    $exe = $dlg.FileName
    New-Item -ItemType Directory -Force -Path $dados | Out-Null
    Set-Content -Path $arqPath -Value $exe -Encoding UTF8
  } else {
    Falhar 'REAPER nao encontrado. Instale o REAPER e abra o INICIAR de novo.'
  }
}
Write-Host "REAPER: $exe"

# 3) abre o REAPER ja rodando o script
Start-Process -FilePath $exe -ArgumentList ('"' + $destino + '"')
Write-Host 'Abrindo o REAPER... a bolinha PK vai aparecer na tela.'
Start-Sleep -Seconds 2