@echo off
title PKVS Studio - Iniciar
cd /d "%~dp0"
if not exist "%~dp0INICIAR.ps1" (
  echo Extraia o ZIP inteiro para uma pasta antes de abrir o INICIAR.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INICIAR.ps1"
if errorlevel 1 pause