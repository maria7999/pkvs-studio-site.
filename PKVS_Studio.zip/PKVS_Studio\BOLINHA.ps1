# PKVS Studio - bolinha flutuante PK com anel RGB animado (nao precisa de extensao nenhuma)
$ErrorActionPreference = 'Stop'
$dados = Join-Path $env:APPDATA 'VS_Estudio_Henzo'
New-Item -ItemType Directory -Force -Path $dados | Out-Null
$mutex = $null
try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  Add-Type @"
using System.Runtime.InteropServices;
public class PkDpi { [DllImport("user32.dll")] public static extern bool SetProcessDPIAware(); }
"@
  [void][PkDpi]::SetProcessDPIAware()

  $mutex = New-Object System.Threading.Mutex($false, 'Local\PKVS_Bolinha_Henzo')
  if (-not $mutex.WaitOne(0)) { exit }

  $aqui = Split-Path -Parent $MyInvocation.MyCommand.Path

  $codigo = @'
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

public class PkBola : Form
{
    const int W = 100;          // tamanho da janela (sobra espaco pro brilho)
    const float C = 50f;        // centro
    const int OFF = 28;         // da janela ate o canto da "caixa" da bolinha
    const int BOX = 44;         // caixa da bolinha (mesma da versao antiga)
    const float R0 = 24f;       // raio do anel em repouso
    const int LUTN = 720;

    [StructLayout(LayoutKind.Sequential)] struct PT { public int x; public int y; }
    [StructLayout(LayoutKind.Sequential)] struct SZ { public int cx; public int cy; }
    [StructLayout(LayoutKind.Sequential, Pack = 1)] struct BLEND { public byte op; public byte flags; public byte alpha; public byte fmt; }

    [DllImport("user32.dll", SetLastError = true)]
    static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, IntPtr pptDst, ref SZ psize, IntPtr hdcSrc, ref PT pptSrc, int crKey, ref BLEND pblend, int dwFlags);
    [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hWnd);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
    [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hDC);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr hObject);

    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);
    delegate bool EnumProc(IntPtr h, IntPtr l);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int n);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);

    static readonly UTF8Encoding utf8 = new UTF8Encoding(false);
    static readonly byte[] lut = MontarLut();

    string dados, arqCmd, arqEstado, arqBolinha, arqPos, arqErro;
    Bitmap frame, logo;
    byte[] buf;
    GraphicsPath monoPath;
    LinearGradientBrush monoBrush;
    System.Windows.Forms.Timer timer;
    Stopwatch sw = Stopwatch.StartNew();
    ContextMenuStrip menu;

    double lastT = 0;
    long tWrite = -100000, tState = 0, tProc = 0;
    float phase = 0f, hov = 0f, prs = 0f, abr = 0f, busy = 0f, rip = -1f;
    bool aberto = false, ocupado = false, down = false, moveu = false, pressed = false, erroGravado = false;
    int encerrado = 0;
    Point p0, l0;
    IntPtr painelHwnd = IntPtr.Zero, achado = IntPtr.Zero;
    uint[] pidsReaper = new uint[0];
    long tJan = 0;

    public static void Executar(string aqui, string dados)
    {
        Application.EnableVisualStyles();
        PkBola f = new PkBola(aqui, dados);
        Application.Run(f);
    }

    public PkBola(string aqui, string dados)
    {
        this.dados = dados;
        arqCmd = Path.Combine(dados, "cmd.txt");
        arqEstado = Path.Combine(dados, "estado.txt");
        arqBolinha = Path.Combine(dados, "bolinha.txt");
        arqPos = Path.Combine(dados, "bolinha_pos.txt");
        arqErro = Path.Combine(dados, "bolinha_erro.txt");

        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        StartPosition = FormStartPosition.Manual;
        ClientSize = new Size(W, W);
        Cursor = Cursors.Hand;

        frame = new Bitmap(W, W, PixelFormat.Format32bppArgb);
        CarregarLogo(aqui);
        MontarMono();

        int px, py;
        Rectangle wa = Screen.PrimaryScreen.WorkingArea;
        px = wa.Right - BOX - 30; py = wa.Top + 140;
        string pp = Ler(arqPos);
        if (pp != null)
        {
            string[] a = pp.Trim().Split(',');
            int vx, vy;
            if (a.Length >= 2 && int.TryParse(a[0].Trim(), out vx) && int.TryParse(a[1].Trim(), out vy)) { px = vx; py = vy; }
        }
        wa = Screen.FromPoint(new Point(px, py)).WorkingArea;
        px = Math.Max(wa.Left, Math.Min(px, wa.Right - BOX));
        py = Math.Max(wa.Top, Math.Min(py, wa.Bottom - BOX));
        Location = new Point(px - OFF, py - OFF);

        menu = new ContextMenuStrip();
        ToolStripItem miAbrir = menu.Items.Add("Abrir / fechar painel");
        ToolStripItem miSair = menu.Items.Add("Sair (fechar o PKVS Studio)");
        miAbrir.Click += delegate { Alternar(); };
        miSair.Click += delegate { Escrever(arqCmd, "sair"); Close(); };

        timer = new System.Windows.Forms.Timer();
        timer.Interval = 30;
        timer.Tick += OnTick;
    }

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x00080000;   // WS_EX_LAYERED
            cp.ExStyle |= 0x00000080;   // WS_EX_TOOLWINDOW
            return cp;
        }
    }
    protected override bool ShowWithoutActivation { get { return true; } }
    protected override void OnPaintBackground(PaintEventArgs e) { }
    protected override void OnPaint(PaintEventArgs e) { }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        try { Render(0); } catch (Exception ex) { GravarErro(ex); }
        timer.Start();
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        try { timer.Stop(); SalvarPos(); } catch { }
        base.OnFormClosed(e);
    }

    // ---------------- arquivos / comunicacao com o REAPER ----------------
    static long Agora() { return (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds; }
    void Escrever(string p, string t) { try { File.WriteAllText(p, t, utf8); } catch { } }
    string Ler(string p) { try { if (File.Exists(p)) return File.ReadAllText(p); } catch { } return null; }
    void GravarErro(Exception ex)
    {
        if (erroGravado) return;
        erroGravado = true;
        Escrever(arqErro, ex.ToString());
    }
    void SalvarPos() { Escrever(arqPos, (Location.X + OFF) + "," + (Location.Y + OFF)); }

    void Alternar()
    {
        Point b = new Point(Location.X + OFF, Location.Y + OFF);
        Rectangle area = Screen.FromPoint(b).WorkingArea;
        int px = b.X + BOX - 490;
        int py = b.Y + BOX + 8;
        if (py + 680 > area.Bottom) py = b.Y - 8 - 680;
        px = Math.Max(area.Left, Math.Min(px, area.Right - 490));
        py = Math.Max(area.Top, py);
        Escrever(arqCmd, "toggle|" + px + "|" + py);
    }

    // true = deve fechar a bolinha
    bool LerEstado()
    {
        string t = Ler(arqEstado);
        if (t == null || t.Trim().Length == 0) return false;
        string[] p = t.Trim().Split('|');
        string est = p[0];
        long ts = 0;
        if (p.Length >= 2) long.TryParse(p[1], out ts);
        if (est == "encerrado") { encerrado++; if (encerrado >= 3) return true; }
        else encerrado = 0;
        bool oc = (p.Length >= 3 && p[2] == "1");
        ocupado = oc;
        if (!oc && ts > 0 && (Agora() - ts) > 20) return true;
        if (est == "aberto") aberto = true;
        else if (est == "fechado") aberto = false;
        return false;
    }

    // ---------------- barra de titulo escura do painel (Windows 10/11) ----------------
    bool EnumCb(IntPtr h, IntPtr l)
    {
        if (!IsWindowVisible(h)) return true;
        StringBuilder sb = new StringBuilder(80);
        GetWindowText(h, sb, 80);
        if (!sb.ToString().StartsWith("PKVS Studio", StringComparison.Ordinal)) return true;
        uint pid;
        GetWindowThreadProcessId(h, out pid);
        foreach (uint q in pidsReaper) { if (q == pid) { achado = h; return false; } }
        return true;
    }

    void EstilizarJanela()
    {
        Process[] ps = Process.GetProcessesByName("reaper");
        pidsReaper = new uint[ps.Length];
        for (int i = 0; i < ps.Length; i++) pidsReaper[i] = (uint)ps[i].Id;
        achado = IntPtr.Zero;
        EnumWindows(new EnumProc(EnumCb), IntPtr.Zero);
        if (achado == IntPtr.Zero) { painelHwnd = IntPtr.Zero; return; }
        if (achado == painelHwnd) return;
        painelHwnd = achado;
        int v = 1;
        DwmSetWindowAttribute(achado, 20, ref v, 4);                 // modo escuro (Win10 2004+ / Win11)
        DwmSetWindowAttribute(achado, 19, ref v, 4);                 // modo escuro (Win10 antigo)
        int cap = 10 | (13 << 8) | (22 << 16);                       // fundo da barra: azul-noite (Win11)
        DwmSetWindowAttribute(achado, 35, ref cap, 4);
        int txt = 204 | (235 << 8) | (255 << 16);                    // texto da barra: azul bem claro
        DwmSetWindowAttribute(achado, 36, ref txt, 4);
        int borda = 110 | (80 << 8) | (255 << 16);                   // borda da janela: roxo neon
        DwmSetWindowAttribute(achado, 34, ref borda, 4);
    }

    // ---------------- mouse ----------------
    static bool Dentro(Point q)
    {
        float dx = q.X - C, dy = q.Y - C;
        return dx * dx + dy * dy <= 32f * 32f;
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button == MouseButtons.Left && Dentro(e.Location))
        {
            down = true; moveu = false; pressed = true;
            p0 = System.Windows.Forms.Cursor.Position;
            l0 = Location;
        }
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (down)
        {
            Point c = System.Windows.Forms.Cursor.Position;
            int dx = c.X - p0.X, dy = c.Y - p0.Y;
            if (moveu || Math.Abs(dx) > 4 || Math.Abs(dy) > 4)
            {
                moveu = true; pressed = false;
                Location = new Point(l0.X + dx, l0.Y + dy);
            }
        }
    }
    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button == MouseButtons.Left && down)
        {
            down = false; pressed = false;
            if (moveu) SalvarPos();
            else { rip = 0f; Alternar(); }
        }
        else if (e.Button == MouseButtons.Right && Dentro(e.Location))
        {
            menu.Show(System.Windows.Forms.Cursor.Position);
        }
    }

    // ---------------- animacao ----------------
    static float Aproxima(float a, float b, float passo)
    {
        if (a < b) { a += passo; if (a > b) a = b; }
        else if (a > b) { a -= passo; if (a < b) a = b; }
        return a;
    }
    static float Suave(float v) { return v * v * (3f - 2f * v); }

    void OnTick(object sender, EventArgs ev)
    {
        try
        {
            double t = sw.Elapsed.TotalSeconds;
            float dt = (float)(t - lastT);
            lastT = t;
            if (dt > 0.1f) dt = 0.1f;
            if (dt < 0f) dt = 0f;
            long ms = sw.ElapsedMilliseconds;

            if (ms - tWrite >= 1000) { tWrite = ms; Escrever(arqBolinha, Agora().ToString()); }
            if (ms - tState >= 250) { tState = ms; if (LerEstado()) { Close(); return; } }
            if (ms - tProc >= 5000)
            {
                tProc = ms;
                if (Process.GetProcessesByName("reaper").Length == 0) { Close(); return; }
            }

            if (ms - tJan >= 1000) { tJan = ms; EstilizarJanela(); }

            Point cp = PointToClient(System.Windows.Forms.Cursor.Position);
            bool hovAlvo = down || Dentro(cp);
            hov = Aproxima(hov, hovAlvo ? 1f : 0f, dt * 8f);
            prs = Aproxima(prs, pressed ? 1f : 0f, dt * 14f);
            abr = Aproxima(abr, aberto ? 1f : 0f, dt * 7f);
            busy = Aproxima(busy, ocupado ? 1f : 0f, dt * 4f);

            float vel = 0.22f + 0.75f * Suave(hov) + 0.9f * busy;
            phase += dt * vel;
            phase -= (float)Math.Floor(phase);
            if (rip >= 0f) { rip += dt * 1.5f; if (rip > 1f) rip = -1f; }

            Render(t);
        }
        catch (Exception ex) { GravarErro(ex); }
    }

    // ---------------- desenho ----------------
    static byte[] MontarLut()
    {
        byte[] l = new byte[LUTN * 3];
        for (int i = 0; i < LUTN; i++)
        {
            float h = (float)i / LUTN * 6f;
            int k = (int)h;
            float f = h - k, q = 1f - f;
            float r = 0f, g = 0f, b = 0f;
            switch (k % 6)
            {
                case 0: r = 1f; g = f; b = 0f; break;
                case 1: r = q; g = 1f; b = 0f; break;
                case 2: r = 0f; g = 1f; b = f; break;
                case 3: r = 0f; g = q; b = 1f; break;
                case 4: r = f; g = 0f; b = 1f; break;
                default: r = 1f; g = 0f; b = q; break;
            }
            l[i * 3] = (byte)(r * 255f);
            l[i * 3 + 1] = (byte)(g * 255f);
            l[i * 3 + 2] = (byte)(b * 255f);
        }
        return l;
    }

    static byte B(float v) { return (byte)(v < 0f ? 0f : (v > 255f ? 255f : v)); }

    void CarregarLogo(string aqui)
    {
        // opcional: se existir pk_logo.png (PNG quadrado), ele substitui o monograma PK desenhado
        string[] cands = new string[] { Path.Combine(aqui, "pk_logo.png"), Path.Combine(dados, "pk_logo.png") };
        foreach (string c in cands)
        {
            if (!File.Exists(c)) continue;
            try
            {
                byte[] bytes = File.ReadAllBytes(c);
                using (MemoryStream ms = new MemoryStream(bytes))
                using (Image src = Image.FromStream(ms)) { logo = new Bitmap(src); }
                return;
            }
            catch { }
        }
    }

    void MontarMono()
    {
        try
        {
            FontFamily ff;
            try { ff = new FontFamily("Segoe UI"); } catch { ff = FontFamily.GenericSansSerif; }
            monoPath = new GraphicsPath();
            monoPath.AddString("PK", ff, (int)FontStyle.Bold, 22f, new PointF(0f, 0f), StringFormat.GenericTypographic);
            RectangleF b = monoPath.GetBounds();
            Matrix m = new Matrix();
            m.Translate(-(b.X + b.Width / 2f), -(b.Y + b.Height / 2f));
            monoPath.Transform(m);
            m.Dispose();
            float hw = b.Width / 2f;
            monoBrush = new LinearGradientBrush(new PointF(-hw, -8f), new PointF(hw, 8f), Color.FromArgb(0, 229, 255), Color.FromArgb(255, 80, 200));
            ColorBlend cb = new ColorBlend(3);
            cb.Colors = new Color[] { Color.FromArgb(0, 229, 255), Color.FromArgb(150, 100, 255), Color.FromArgb(255, 80, 200) };
            cb.Positions = new float[] { 0f, 0.5f, 1f };
            monoBrush.InterpolationColors = cb;
        }
        catch { monoPath = null; monoBrush = null; }
    }

    void Render(double t)
    {
        float h = Suave(hov), p = prs, o = Suave(abr);
        float s = 1f + 0.10f * h - 0.07f * p + 0.012f * (float)Math.Sin(t * 2.2) + 0.02f * busy * (float)Math.Sin(t * 9.0);
        float R = R0 * s;
        float halfW = (4.2f + 1.6f * h) / 2f;

        PintarAnel(R, halfW, h);
        using (Graphics g = Graphics.FromImage(frame))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.TextRenderingHint = TextRenderingHint.AntiAlias;
            PintarMiolo(g, R, halfW, o);
        }
        Aplicar();
    }

    // anel RGB (gradiente conico) + brilho + onda do clique, calculados pixel a pixel
    void PintarAnel(float R, float halfW, float h)
    {
        BitmapData bd = frame.LockBits(new Rectangle(0, 0, W, W), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try
        {
            int stride = bd.Stride;
            if (buf == null || buf.Length != stride * W) buf = new byte[stride * W];

            float baseA = Math.Min(1f, 0.55f + 0.30f * h + 0.25f * busy);
            float glowK = 0.34f + 0.55f * h + 0.30f * busy;
            float sigma = 4.2f + 3.0f * h;
            float inv2s = 1f / (2f * sigma * sigma);
            float headDeg = phase * 360f;
            float maxD = R + 28f;
            float minD = R - halfW - 2.5f;
            bool ripOn = rip >= 0f;
            float ripR = R + 3f + (ripOn ? rip : 0f) * 20f;
            float ripA = ripOn ? (1f - rip) * (1f - rip) * 0.85f : 0f;

            for (int y = 0; y < W; y++)
            {
                for (int x = 0; x < W; x++)
                {
                    int i = y * stride + x * 4;
                    float dx = x + 0.5f - C, dy = y + 0.5f - C;
                    float d = (float)Math.Sqrt(dx * dx + dy * dy);
                    if (d > maxD || d < minD) { buf[i] = 0; buf[i + 1] = 0; buf[i + 2] = 0; buf[i + 3] = 0; continue; }

                    float ang = (float)(Math.Atan2(dy, dx) * 57.29578);
                    if (ang < 0f) ang += 360f;
                    float behind = headDeg - ang;
                    behind -= 360f * (float)Math.Floor(behind / 360f);
                    float comet = behind < 100f ? 1f - behind / 100f : (behind > 346f ? (behind - 346f) / 14f : 0f);
                    comet *= comet;

                    float hue = ang / 360f - phase;
                    hue -= (float)Math.Floor(hue);
                    int li = (int)(hue * LUTN);
                    if (li >= LUTN) li = LUTN - 1;
                    li *= 3;
                    float lr = lut[li], lg = lut[li + 1], lb = lut[li + 2];
                    float wm = comet * 0.72f;
                    float cr = lr + (255f - lr) * wm, cg = lg + (255f - lg) * wm, cb = lb + (255f - lb) * wm;

                    float dist = Math.Abs(d - R);
                    float ex = dist - halfW; if (ex < 0f) ex = 0f;

                    // brilho (camada de baixo)
                    float oa = glowK * (0.30f + 0.70f * comet) * (float)Math.Exp(-ex * ex * inv2s) * 0.6f;
                    float opr = lr * oa, opg = lg * oa, opb = lb * oa;

                    // onda do clique
                    if (ripOn)
                    {
                        float rc = 1.5f - Math.Abs(d - ripR);
                        if (rc > 0f)
                        {
                            if (rc > 1f) rc = 1f;
                            float a = rc * ripA, ia = 1f - a;
                            opr = cr * a + opr * ia; opg = cg * a + opg * ia; opb = cb * a + opb * ia;
                            oa = a + oa * ia;
                        }
                    }

                    // anel (camada de cima)
                    float cov = halfW + 0.5f - dist;
                    if (cov > 0f)
                    {
                        if (cov > 1f) cov = 1f;
                        float a = cov * (baseA + (1f - baseA) * comet), ia = 1f - a;
                        opr = cr * a + opr * ia; opg = cg * a + opg * ia; opb = cb * a + opb * ia;
                        oa = a + oa * ia;
                    }

                    if (oa < 0.004f) { buf[i] = 0; buf[i + 1] = 0; buf[i + 2] = 0; buf[i + 3] = 0; }
                    else
                    {
                        buf[i] = B(opb / oa);
                        buf[i + 1] = B(opg / oa);
                        buf[i + 2] = B(opr / oa);
                        buf[i + 3] = B(oa * 255f);
                    }
                }
            }
            Marshal.Copy(buf, 0, bd.Scan0, buf.Length);
        }
        finally { frame.UnlockBits(bd); }
    }

    // miolo: disco de vidro escuro + monograma PK em degrade neon (ou X quando o painel esta aberto)
    void PintarMiolo(Graphics g, float R, float halfW, float o)
    {
        float ri = R - halfW + 0.3f;
        RectangleF disc = new RectangleF(C - ri, C - ri, 2f * ri, 2f * ri);
        using (GraphicsPath gp = new GraphicsPath())
        {
            gp.AddEllipse(disc);
            using (LinearGradientBrush br = new LinearGradientBrush(disc, Color.FromArgb(40, 28, 78), Color.FromArgb(9, 9, 20), 80f))
                g.FillPath(br, gp);

            float sc = ri / 22f * (1f - 0.12f * o);

            if (logo != null)
            {
                float lr = (ri - 2.5f) * (1f - 0.10f * o);
                using (GraphicsPath lp = new GraphicsPath())
                {
                    lp.AddEllipse(C - lr, C - lr, 2f * lr, 2f * lr);
                    g.SetClip(lp);
                    g.DrawImage(logo, new RectangleF(C - lr, C - lr, 2f * lr, 2f * lr));
                    g.ResetClip();
                }
            }
            else if (monoPath != null && monoBrush != null)
            {
                GraphicsState st = g.Save();
                g.TranslateTransform(C, C);
                g.ScaleTransform(sc, sc);
                using (Pen pn = new Pen(Color.FromArgb(70, 150, 90, 255), 3.4f))
                {
                    pn.LineJoin = LineJoin.Round;
                    g.DrawPath(pn, monoPath);
                }
                g.FillPath(monoBrush, monoPath);
                g.Restore(st);
            }
            else
            {
                using (Font f = new Font("Segoe UI", ri * 0.8f, FontStyle.Bold, GraphicsUnit.Pixel))
                using (StringFormat sf = new StringFormat())
                {
                    sf.Alignment = StringAlignment.Center; sf.LineAlignment = StringAlignment.Center;
                    g.DrawString("PK", f, Brushes.White, disc, sf);
                }
            }

            // painel aberto: escurece e mostra o X
            if (o > 0.01f)
            {
                using (SolidBrush sb = new SolidBrush(Color.FromArgb((int)(190f * o), 12, 8, 30)))
                    g.FillPath(sb, gp);
                float a = ri * 0.32f;
                using (Pen xp = new Pen(Color.FromArgb((int)(255f * o), 255, 255, 255), 3.4f))
                {
                    xp.StartCap = LineCap.Round; xp.EndCap = LineCap.Round;
                    g.DrawLine(xp, C - a, C - a, C + a, C + a);
                    g.DrawLine(xp, C + a, C - a, C - a, C + a);
                }
            }

            // reflexo de vidro no topo
            g.SetClip(gp);
            RectangleF gl = new RectangleF(C - ri * 0.78f, C - ri * 0.97f, ri * 1.56f, ri * 0.95f);
            using (LinearGradientBrush gb = new LinearGradientBrush(gl, Color.FromArgb(60, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillEllipse(gb, gl);
            g.ResetClip();

            // fio de luz na borda
            using (Pen rim = new Pen(Color.FromArgb(40, 255, 255, 255), 1f))
                g.DrawEllipse(rim, disc);
        }
    }

    void Aplicar()
    {
        IntPtr scr = GetDC(IntPtr.Zero);
        IntPtr mem = CreateCompatibleDC(scr);
        IntPtr hb = IntPtr.Zero, old = IntPtr.Zero;
        try
        {
            hb = frame.GetHbitmap(Color.FromArgb(0));
            old = SelectObject(mem, hb);
            SZ sz = new SZ(); sz.cx = W; sz.cy = W;
            PT src = new PT();
            BLEND bf = new BLEND(); bf.op = 0; bf.flags = 0; bf.alpha = 255; bf.fmt = 1;
            UpdateLayeredWindow(Handle, scr, IntPtr.Zero, ref sz, mem, ref src, 0, ref bf, 2);
        }
        finally
        {
            if (old != IntPtr.Zero) SelectObject(mem, old);
            if (hb != IntPtr.Zero) DeleteObject(hb);
            DeleteDC(mem);
            ReleaseDC(IntPtr.Zero, scr);
        }
    }
}
'@

  Add-Type -TypeDefinition $codigo -ReferencedAssemblies 'System.Windows.Forms','System.Drawing' -Language CSharp
  [PkBola]::Executar($aqui, $dados)
}
catch {
  try { [IO.File]::WriteAllText((Join-Path $dados 'bolinha_erro.txt'), ($_ | Out-String)) } catch {}
}
finally {
  if ($mutex) { try { $mutex.ReleaseMutex() } catch {} }
}
