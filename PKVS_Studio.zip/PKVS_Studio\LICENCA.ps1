﻿# PKVS Studio - verificacao de licenca (key)
# Chamado pelo script do REAPER, em segundo plano. Nao precisa de senha de administrador.
# Escreve o resultado em um arquivo (-Saida), uma informacao por linha:
#   resultado=ok | recusada | rede | erro
#   motivo=invalida | revogada | outro_pc | expirada | dados_invalidos   (quando recusada)
#   plano=... expira_em=<milissegundos> dias=... maquina=<id do PC>
param(
  [Parameter(Mandatory = $true)][string]$Chave,
  [string]$Saida = '',
  [string]$Servidor = 'https://pkvs-keys.pkvs-studio.workers.dev',
  [int]$Espera = 8
)

$ErrorActionPreference = 'Stop'
if (-not $Saida) { $Saida = Join-Path $env:APPDATA 'VS_Estudio_Henzo\licenca_resp.txt' }
try { New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Saida) | Out-Null } catch {}
# PowerShell 5.1 do Windows precisa disto para falar HTTPS com a Cloudflare
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

function Gravar([string[]]$linhas) {
  # grava em arquivo temporario e renomeia, para o REAPER nunca ler o arquivo pela metade
  $tmp = "$Saida.tmp"
  $enc = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($tmp, (($linhas -join "`r`n") + "`r`n"), $enc)
  Move-Item -LiteralPath $tmp -Destination $Saida -Force
}

# ID estavel deste computador: hash do MachineGuid do Windows (o GUID em si nao sai do PC)
function Obter-IdMaquina {
  $guid = $null
  try {
    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry64)
    $k = $base.OpenSubKey('SOFTWARE\Microsoft\Cryptography')
    if ($k) { $guid = $k.GetValue('MachineGuid') }
  } catch {}
  if (-not $guid) {
    try { $guid = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid } catch {}
  }
  if (-not $guid) { return $null }
  $sha = [System.Security.Cryptography.SHA256]::Create()
  $bytes = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes('PKVS-STUDIO|' + $guid.ToString().ToLower()))
  return (($bytes | ForEach-Object { $_.ToString('x2') }) -join '').Substring(0, 32)
}

try {
  # a key so pode ter letras, numeros e hifen (evita qualquer coisa estranha)
  $chaveLimpa = ($Chave.ToUpper() -replace '[^A-Z0-9\-]', '')
  $id = Obter-IdMaquina
  if (-not $id) {
    Gravar @('resultado=erro', 'motivo=sem_id', 'maquina=')
    exit 0
  }

  $corpo = (@{ chave = $chaveLimpa; maquina = $id } | ConvertTo-Json -Compress)
  $bytesCorpo = [System.Text.Encoding]::UTF8.GetBytes($corpo)

  $resp = $null
  $textoResp = $null
  try {
    $req = [System.Net.HttpWebRequest]::Create("$Servidor/validar")
    $req.Method = 'POST'
    $req.ContentType = 'application/json; charset=utf-8'
    $req.UserAgent = 'PKVS-Studio'
    $req.Timeout = $Espera * 1000
    $req.ReadWriteTimeout = $Espera * 1000
    $req.ContentLength = $bytesCorpo.Length
    $st = $req.GetRequestStream(); $st.Write($bytesCorpo, 0, $bytesCorpo.Length); $st.Close()
    $res = $req.GetResponse()
    $sr = New-Object System.IO.StreamReader($res.GetResponseStream(), [System.Text.Encoding]::UTF8)
    $textoResp = $sr.ReadToEnd(); $sr.Close(); $res.Close()
  } catch [System.Net.WebException] {
    # erro HTTP com corpo (ex.: 400 dados_invalidos) ainda e uma resposta do servidor
    if ($_.Exception.Response) {
      try {
        $sr = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream(), [System.Text.Encoding]::UTF8)
        $textoResp = $sr.ReadToEnd(); $sr.Close()
      } catch {}
    }
  }

  if ($textoResp) {
    try { $resp = $textoResp | ConvertFrom-Json } catch { $resp = $null }
  }

  if ($null -eq $resp) {
    Gravar @('resultado=rede', 'motivo=sem_resposta', "maquina=$id")
    exit 0
  }

  if ($resp.ok -eq $true) {
    $exp = [int64]$resp.expira_em
    Gravar @('resultado=ok', "plano=$($resp.plano)", "expira_em=$exp", "dias=$($resp.dias_restantes)", "maquina=$id")
  } else {
    $motivo = if ($resp.motivo) { [string]$resp.motivo } else { 'invalida' }
    Gravar @('resultado=recusada', "motivo=$motivo", "maquina=$id")
  }
} catch {
  try { Gravar @('resultado=erro', 'motivo=falha', 'maquina=') } catch {}
}
exit 0
