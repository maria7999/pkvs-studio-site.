#!/bin/bash
# PKVS Studio (Mac) - seletor de pastas
# Abre a janela de pastas do macOS (Cmd ou Shift para marcar varias).
# Grava "#OK" e depois o caminho de cada pasta escolhida, uma por linha, no arquivo de -saida.
# Opcoes: -saida ARQUIVO   -inicial PASTA   -msg "texto"   -um (so uma pasta)
export PATH="/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

saida=""; inicial=""; msg="Selecione a pasta"; multiplo=1
while [ $# -gt 0 ]; do
  case "$1" in
    -saida)   saida="$2"; shift 2 ;;
    -inicial) inicial="$2"; shift 2 ;;
    -msg)     msg="$2"; shift 2 ;;
    -um)      multiplo=0; shift ;;
    *)        shift ;;
  esac
done
[ -z "$saida" ] && exit 1

dados="$HOME/Library/Application Support/VS_Estudio_Henzo"
mkdir -p "$dados" 2>/dev/null

gravar() {
  printf '%s' "$1" > "$saida.tmp" 2>/dev/null && mv -f "$saida.tmp" "$saida"
}

# escapa barra e aspas para dentro de um texto do AppleScript
esc() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

msg_e=$(esc "$msg")
padrao=""
if [ -n "$inicial" ] && [ -d "$inicial" ]; then
  padrao="default location (POSIX file \"$(esc "$inicial")\")"
fi
opc=""
[ "$multiplo" = "1" ] && opc="with multiple selections allowed"

erro_f=$(mktemp "${TMPDIR:-/tmp}/pkvs_osa.XXXXXX")
res=$(/usr/bin/osascript 2>"$erro_f" <<OSA
try
  tell current application to activate
end try
set sel to choose folder with prompt "$msg_e" $padrao $opc
set out to ""
if class of sel is list then
  repeat with p in sel
    set out to out & (POSIX path of (contents of p)) & linefeed
  end repeat
else
  set out to POSIX path of sel
end if
return out
OSA
)
codigo=$?
erro=$(cat "$erro_f" 2>/dev/null); rm -f "$erro_f"

if [ $codigo -ne 0 ]; then
  case "$erro" in
    *"-128"*|*"User canceled"*|*"Usu"*"cancel"*)
      gravar "#OK"$'\n' ;;      # cancelou: lista vazia
    *)
      msg_erro=$(printf '%s' "$erro" | tr '\r\n' '  ')
      printf '%s\n%s\n' "$(date)" "$erro" > "$dados/pastas_erro.txt" 2>/dev/null
      gravar "#ERRO $msg_erro" ;;
  esac
  exit 0
fi

lista=$(printf '%s\n' "$res" | sed -e 's:/*$::' | sed -e '/^[[:space:]]*$/d')
gravar "#OK"$'\n'"$lista"$'\n'
exit 0
