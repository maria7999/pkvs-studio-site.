-- ============================================================
--  PKVS Studio  -  Ferramenta de preparo de VS
--  Script para REAPER (Lua). Nao precisa instalar extensao.
--  Como abrir: Actions > Show action list > New action >
--  Load ReaScript... > escolha este arquivo.
-- ============================================================

local r = reaper
local TITULO = "PKVS Studio"
local TITULO_JANELA = "PKVS Studio \xE2\x80\x94 Central de Produ\xC3\xA7\xC3\xA3o"
local EXT = "VS_HENZO"

-- Configuracoes (pode mudar)
local GAP_ENTRE_MUSICAS = 2          -- segundos de espaco entre as musicas (o arredondamento soma ate 1s: fica entre 2 e 3)
local CRIAR_MARCADOR_INICIO = true   -- marcador no inicio de cada musica
local LUFS_PADRAO = -14
local EXTENSOES = { wav=true, mp3=true, flac=true, aif=true, aiff=true, ogg=true, m4a=true }

-- ------------------------------------------------------------
-- Categorias de instrumentos (ordem = ordem das pastas no projeto)
-- ------------------------------------------------------------
local CATS = {
  { id="CLICK", nome="CLICK / GUIA", curto="click", cor={235,200,60}, transpor=false,
    kw={"click","clk","metronomo","guia","guide","cue","cues","contagem","count"} },
  { id="BATERIA", nome="BATERIA", curto="bateria", cor={220,70,70}, transpor=false,
    kw={"bateria","drum","drums","kick","bumbo","snare","caixa","tom","toms","hihat","hat","chimbal","overhead","overheads","oh","cymbal","cymbals","prato","pratos","ride","crash","bd","sd"} },
  { id="PERC", nome="PERCUSSAO", curto="percussao", cor={230,130,60}, transpor=false,
    kw={"perc","percuss","percussao","percussion","shaker","pandeiro","conga","congas","bongo","tambourine","tamborim","claps","palmas","cowbell","zabumba","triangulo","agogo"} },
  { id="BAIXO", nome="BAIXO", curto="baixo", cor={150,90,200}, transpor=true,
    kw={"baixo","bass","sub","contrabaixo","bx"} },
  { id="GUITARRA", nome="GUITARRAS / VIOLOES", curto="guitarra", cor={70,140,220}, transpor=true,
    kw={"guitarra","guitarras","guitar","guitars","gtr","gtrs","violao","violoes","viola","acoustic","acustico","ukulele","cavaco","banjo"} },
  { id="TECLADO", nome="TECLADOS / SYNTH", curto="teclado", cor={60,190,170}, transpor=true,
    kw={"teclado","teclados","keys","key","keyboard","keyboards","piano","synth","synths","pad","pads","organ","orgao","rhodes","wurlitzer","strings","string","cordas","violino","violin","cello","orquestra","acordeon","accordion","sanfona"} },
  { id="METAIS", nome="METAIS / SOPROS", curto="metais", cor={200,160,60}, transpor=true,
    kw={"metais","brass","sax","saxofone","trumpet","trompete","trombone","flauta","flute","horn","horns"} },
  { id="VOCAL", nome="VOCAIS", curto="vocal", cor={240,110,170}, transpor=true,
    kw={"voz","vozes","vocal","vocais","vocals","vox","bgv","bv","bvs","backing","coro","choir","cantor","cantora"} },
  { id="LOOPS", nome="LOOPS / SEQUENCIA", curto="loop", cor={110,200,90}, transpor=true,
    kw={"loop","loops","fx","sfx","efeito","efeitos","ambience","ambiente","seq","sequence","sequencia","sample","samples","playback"} },
  { id="OUTROS", nome="OUTROS", curto="outros", cor={150,150,150}, transpor=true, kw={} },
}
local CAT_POR_ID = {}
for i, c in ipairs(CATS) do c.ordem = i; CAT_POR_ID[c.id] = c end
local CAT_OUTROS = CATS[#CATS]

local ACENTOS = {
  {"\xC3\xA1","a"},{"\xC3\xA0","a"},{"\xC3\xA2","a"},{"\xC3\xA3","a"},{"\xC3\xA4","a"},
  {"\xC3\xA9","e"},{"\xC3\xA8","e"},{"\xC3\xAA","e"},{"\xC3\xAD","i"},{"\xC3\xAC","i"},
  {"\xC3\xB3","o"},{"\xC3\xB2","o"},{"\xC3\xB4","o"},{"\xC3\xB5","o"},
  {"\xC3\xBA","u"},{"\xC3\xB9","u"},{"\xC3\xBC","u"},{"\xC3\xA7","c"},
  {"\xC3\x81","a"},{"\xC3\x80","a"},{"\xC3\x82","a"},{"\xC3\x83","a"},
  {"\xC3\x89","e"},{"\xC3\x8A","e"},{"\xC3\x8D","i"},
  {"\xC3\x93","o"},{"\xC3\x94","o"},{"\xC3\x95","o"},{"\xC3\x9A","u"},{"\xC3\x87","c"},
}

local function normalizar(s)
  s = s or ""
  for _, p in ipairs(ACENTOS) do s = s:gsub(p[1], p[2]) end
  s = s:lower()
  s = s:gsub("[^%w]+", " ")
  return " " .. s .. " "
end

local function identificar(nome)
  local norm = normalizar(nome)
  local tokens = {}
  for tok in norm:gmatch("%S+") do
    tokens[tok] = true
    local base = tok:gsub("%d+$", "")
    if base ~= "" then tokens[base] = true end
  end
  local CAT_LOOPS = CAT_POR_ID["LOOPS"]
  if tokens["fx"] or tokens["sfx"] or tokens["efx"] then return CAT_LOOPS end
  if not (tokens["click"] or tokens["clk"] or tokens["metronomo"] or tokens["contagem"] or tokens["count"]) then
    if tokens["guia"] or tokens["guide"] or tokens["regencia"] or tokens["cue"] or tokens["cues"] or tokens["gv"] then
      return CAT_POR_ID["VOCAL"]
    end
  end
  for _, c in ipairs(CATS) do
    for _, k in ipairs(c.kw) do
      if tokens[k] then return c end
      if #k >= 6 and norm:find(k, 1, true) then return c end
    end
  end
  return CAT_OUTROS
end

local function catPorTexto(t)
  local n = normalizar(t)
  for _, c in ipairs(CATS) do
    if n == normalizar(c.curto) or n == normalizar(c.nome) then return c end
  end
  local c = identificar(t)
  if c.id ~= "OUTROS" then return c end
  return nil
end

-- ------------------------------------------------------------
-- Auxiliares
-- ------------------------------------------------------------
local function nativeCor(c) return r.ColorToNative(c[1], c[2], c[3]) | 0x1000000 end

local function parseNum(s)
  s = (s or ""):gsub(",", "."):gsub("^%s+", ""):gsub("%s+$", "")
  return tonumber(s)
end

local function nomeTrack(tr)
  local _, n = r.GetSetMediaTrackInfo_String(tr, "P_NAME", "", false)
  return n or ""
end
local function setNomeTrack(tr, n) r.GetSetMediaTrackInfo_String(tr, "P_NAME", n, true) end
local function getExt(tr, k)
  local ok, v = r.GetSetMediaTrackInfo_String(tr, "P_EXT:" .. k, "", false)
  if ok then return v end
  return ""
end
local function setExt(tr, k, v) r.GetSetMediaTrackInfo_String(tr, "P_EXT:" .. k, v, true) end
local function ehPasta(tr) return getExt(tr, "vs_folder") == "1" end
local function catDaTrack(tr)
  local id = getExt(tr, "vs_cat")
  if id ~= "" and CAT_POR_ID[id] then return CAT_POR_ID[id] end
  return identificar(nomeTrack(tr))
end

local status = { texto = "Pronto para come\xC3\xA7ar. (v3 - tracks unificadas)", tipo = "ok" }
local function setStatus(t, tipo) status.texto = t; status.tipo = tipo or "ok" end

-- ------------------------------------------------------------
-- Importar musicas
-- ------------------------------------------------------------
local function listarAudios(dir)
  local arqs, i = {}, 0
  while true do
    local f = r.EnumerateFiles(dir, i)
    if not f then break end
    local ext = f:match("%.([^%.]+)$")
    if ext and EXTENSOES[ext:lower()] then arqs[#arqs + 1] = f end
    i = i + 1
  end
  table.sort(arqs, function(a, b) return a:lower() < b:lower() end)
  return arqs
end

local function limparNome(arq)
  local n = arq:gsub("%.[^%.]+$", "")
  n = n:gsub("_", " ")
  n = n:match("^(.-)%s+%-%s+") or n        -- tira " - NOME DA MUSICA - CLUBE DO VS"
  n = n:gsub("^%d+[%s%-%.]+", "")
  n = n:gsub("^%s+", "")
  n = n:gsub("%s+%d+$", "")                -- tira numero final (BASS 22, CLICK 148)
  n = n:gsub("%s+$", "")
  if n == "" then n = arq end
  return n
end

local function fimDoProjeto()
  local fim = 0
  for i = 0, r.CountMediaItems(0) - 1 do
    local it = r.GetMediaItem(0, i)
    local e = r.GetMediaItemInfo_Value(it, "D_POSITION") + r.GetMediaItemInfo_Value(it, "D_LENGTH")
    if e > fim then fim = e end
  end
  local i = 0
  while true do
    local ret, isrgn, pos, rgnend = r.EnumProjectMarkers3(0, i)
    if ret == 0 then break end
    if isrgn and rgnend > fim then fim = rgnend end
    i = i + 1
  end
  return fim
end

local function regiaoExiste(nome)
  local i = 0
  while true do
    local ret, isrgn, _, _, n = r.EnumProjectMarkers3(0, i)
    if ret == 0 then break end
    if isrgn and n == nome then return true end
    i = i + 1
  end
  return false
end

-- Familias de nomes: instrumentos com nome igual ou compativel dividem a mesma track
local ALIAS_FAMILIA = {
  bass = "baixo", contrabaixo = "baixo", bx = "baixo",
  drums = "bateria", drum = "bateria",
  vocal = "voz", vocals = "voz", vox = "voz", vozes = "voz", vocais = "voz",
  guitar = "guitarra", gtr = "guitarra", guitarras = "guitarra",
  violoes = "violao",
  keys = "teclado", teclados = "teclado",
  -- percussao (PERCUSSA, PERCUSSAO, PERC...) = uma track so
  perc = "percussao", percussa = "percussao", percussoes = "percussao", percussion = "percussao",
  -- sanfona e acordeon = uma track so
  acordeon = "sanfona", acordeao = "sanfona", accordion = "sanfona", acordeom = "sanfona",
  -- efeitos: FX e EFX = uma track so
  efx = "fx", sfx = "fx", efeito = "fx", efeitos = "fx",
  ["voz guia"] = "voz",
  -- nomes em ingles -> portugues
  keyboard = "teclado", keyboards = "teclado",
  strings = "cordas", string = "cordas", violin = "violino",
  horns = "metais", horn = "metais", brass = "metais",
  flute = "flauta", trumpet = "trompete", organ = "orgao", choir = "coro",
}
-- nome (e categoria) padrao da track quando a familia tem varias grafias
local NOME_PADRAO = {
  percussao = "PERCUSSAO", sanfona = "SANFONA", voz = "VOZ", fx = "EFEITOS",
  bateria = "BATERIA", baixo = "BAIXO", guitarra = "GUITARRA", teclado = "TECLADO",
  cordas = "CORDAS", violino = "VIOLINO", metais = "METAIS", flauta = "FLAUTA",
  trompete = "TROMPETE", orgao = "ORGAO", coro = "CORO",
}
local CAT_PADRAO = { fx = "LOOPS", voz = "VOCAL" }

-- devolve a chave da familia e o nome que a track deve ter
local function familia(nome)
  local norm = normalizar(nome)
  local palavras, tem = {}, {}
  for w in norm:gmatch("%S+") do palavras[#palavras + 1] = w; tem[w] = true end
  if tem["click"] or tem["clk"] or tem["metronomo"] then return "click", "CLICK" end
  if tem["guia"] or tem["guide"] or tem["regencia"] or tem["cue"] or tem["cues"] or tem["gv"] then
    return "voz", "VOZ"   -- voz guia e voz ficam na MESMA track
  end
  local p1 = palavras[1] or "outros"
  local base = (p1:gsub("%d+$", ""))
  if base == "" then base = p1 end
  base = ALIAS_FAMILIA[base] or base
  local exib = ((nome:match("^%s*(%S+)") or nome):gsub("%d+$", ""))
  if exib == "" then exib = nome end
  if NOME_PADRAO[base] then return base, NOME_PADRAO[base] end
  return base, exib:upper()
end

local function familiaDaTrack(tr)
  local f = getExt(tr, "vs_fam")
  if f ~= "" then return ALIAS_FAMILIA[f] or f end
  return (familia(nomeTrack(tr)))
end

-- nome sem o numero do final: "SANFONA 2" e "Sanfona" -> "sanfona"; "Guitarra Base" continua "guitarra base"
local function chaveExata(nome)
  if (familia(nome)) == "voz" then return "voz" end
  local palavras = {}
  for w in normalizar(nome):gmatch("%S+") do palavras[#palavras + 1] = w end
  while #palavras > 1 and palavras[#palavras]:match("^%d+$") do palavras[#palavras] = nil end
  local ult = palavras[#palavras]
  if ult then
    local b = (ult:gsub("%d+$", ""))
    if b ~= "" then palavras[#palavras] = b end
  end
  if palavras[1] then palavras[1] = ALIAS_FAMILIA[palavras[1]] or palavras[1] end
  return table.concat(palavras, " ")
end

-- true se nao ha nenhum item da track no intervalo [ini, fim]
local function trackLivre(tr, ini, fim)
  for k = 0, r.CountTrackMediaItems(tr) - 1 do
    local it = r.GetTrackMediaItem(tr, k)
    local p = r.GetMediaItemInfo_Value(it, "D_POSITION")
    local e = p + r.GetMediaItemInfo_Value(it, "D_LENGTH")
    if p < fim - 0.001 and e > ini + 0.001 then return false end
  end
  return true
end

local function registrarNaTrack(tr, chave, nome)
  if getExt(tr, "vs_fam") ~= chave then setExt(tr, "vs_fam", chave) end
  local nomes = getExt(tr, "vs_nomes")
  local n = nome:lower()
  if not ("|" .. nomes .. "|"):find("|" .. n .. "|", 1, true) then
    setExt(tr, "vs_nomes", (nomes == "") and n or (nomes .. "|" .. n))
  end
end

local function nomeDeTrackExiste(nome)
  for i = 0, r.CountTracks(0) - 1 do
    local tr = r.GetTrack(0, i)
    if not ehPasta(tr) and nomeTrack(tr):lower() == nome:lower() then return true end
  end
  return false
end

local function acharOuCriarTrack(nome, cat, ini, fim)
  local chave, exib = familia(nome)
  local candidatas = {}
  for i = 0, r.CountTracks(0) - 1 do
    local tr = r.GetTrack(0, i)
    if not ehPasta(tr) and familiaDaTrack(tr) == chave and trackLivre(tr, ini, fim) then
      candidatas[#candidatas + 1] = tr
    end
  end
  -- 0) mesmo nome so com numero diferente (SANFONA / SANFONA 2, LEAD / LEAD 2): sempre na mesma track
  local kx = chaveExata(nome)
  for i = 0, r.CountTracks(0) - 1 do
    local tr = r.GetTrack(0, i)
    if not ehPasta(tr) and familiaDaTrack(tr) == chave then
      local mesmo = (chaveExata(nomeTrack(tr)) == kx)
      if not mesmo then
        for n in (getExt(tr, "vs_nomes") .. "|"):gmatch("([^|]*)|") do
          if n ~= "" and chaveExata(n) == kx then mesmo = true; break end
        end
      end
      if mesmo then
        registrarNaTrack(tr, chave, nome)
        return tr
      end
    end
  end
  -- 1) prefere a track que ja recebeu exatamente esse nome
  for _, tr in ipairs(candidatas) do
    if ("|" .. getExt(tr, "vs_nomes") .. "|"):find("|" .. nome:lower() .. "|", 1, true) then
      registrarNaTrack(tr, chave, nome)
      return tr
    end
  end
  -- 2) qualquer track livre da mesma familia
  if candidatas[1] then
    registrarNaTrack(candidatas[1], chave, nome)
    return candidatas[1]
  end
  -- 3) cria uma nova (se o nome ja existe e esta ocupada, numera)
  local nomeNovo, n = exib, 2
  while nomeDeTrackExiste(nomeNovo) do nomeNovo = exib .. " " .. n; n = n + 1 end
  local idx = r.CountTracks(0)
  r.InsertTrackAtIndex(idx, true)
  local tr = r.GetTrack(0, idx)
  setNomeTrack(tr, nomeNovo)
  setExt(tr, "vs_cat", cat.id)
  r.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", nativeCor(cat.cor))
  registrarNaTrack(tr, chave, nome)
  return tr
end

-- renomeia para o nome padrao (PERCUSSA -> PERCUSSAO, ACORDEON -> SANFONA, EFX -> FX...) e acerta a categoria
local function padronizarNome(tr)
  if ehPasta(tr) then return end
  local fam = familiaDaTrack(tr)
  local padrao = NOME_PADRAO[fam]
  if not padrao then return end
  if chaveExata(nomeTrack(tr)) ~= fam then return end   -- ex.: "SANFONA SOLO" continua como esta
  if nomeTrack(tr) ~= padrao and not nomeDeTrackExiste(padrao) then setNomeTrack(tr, padrao) end
  local catId = CAT_PADRAO[fam]
  if catId and CAT_POR_ID[catId] and getExt(tr, "vs_cat") ~= catId then
    setExt(tr, "vs_cat", catId)
    r.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", nativeCor(CAT_POR_ID[catId].cor))
  end
end

-- junta a track com outra de mesmo nome (so muda o numero), mesmo que os itens se sobreponham.
-- So junta se nenhuma das duas tem FX e se mudo/pan sao iguais; o volume da track e passado pros itens.
local function fundirExato(tr, exatos)
  if ehPasta(tr) then return false end
  local nIt = r.CountTrackMediaItems(tr)
  if nIt == 0 then return false end
  local kx = familiaDaTrack(tr) .. "|" .. chaveExata(nomeTrack(tr))
  local d = exatos[kx]
  if not d then
    exatos[kx] = tr
    return false
  end
  if r.TrackFX_GetCount(tr) ~= 0 or r.TrackFX_GetCount(d) ~= 0 then return false end
  if math.abs(r.GetMediaTrackInfo_Value(tr, "D_PAN") - r.GetMediaTrackInfo_Value(d, "D_PAN")) > 0.001 then return false end
  if r.GetMediaTrackInfo_Value(tr, "B_MUTE") ~= r.GetMediaTrackInfo_Value(d, "B_MUTE") then return false end
  local vd = r.GetMediaTrackInfo_Value(d, "D_VOL")
  local ratio = (vd > 0.0001) and (r.GetMediaTrackInfo_Value(tr, "D_VOL") / vd) or 1
  for k = nIt - 1, 0, -1 do
    local it = r.GetTrackMediaItem(tr, k)
    if math.abs(ratio - 1) > 0.001 then
      r.SetMediaItemInfo_Value(it, "D_VOL", r.GetMediaItemInfo_Value(it, "D_VOL") * ratio)
    end
    r.MoveMediaItemToTrack(it, d)
  end
  r.DeleteTrack(tr)
  return true
end

-- junta tracks da mesma familia quando os itens nao se sobrepoem (musicas em sequencia)
local function consolidarTracks()
  local fundidas = 0
  local tracks = {}
  for k = 0, r.CountTracks(0) - 1 do tracks[#tracks + 1] = r.GetTrack(0, k) end
  local destinos, exatos = {}, {}
  for _, tr in ipairs(tracks) do
    padronizarNome(tr)
    local chave = familiaDaTrack(tr)
    destinos[chave] = destinos[chave] or {}
    if fundirExato(tr, exatos) then
      fundidas = fundidas + 1
    else
    local movido = false
    local nIt = r.CountTrackMediaItems(tr)
    local simples = nIt > 0 and r.TrackFX_GetCount(tr) == 0
    if simples then
      for _, dest in ipairs(destinos[chave]) do
        local igual = math.abs(r.GetMediaTrackInfo_Value(tr, "D_VOL") - r.GetMediaTrackInfo_Value(dest, "D_VOL")) < 0.001
          and math.abs(r.GetMediaTrackInfo_Value(tr, "D_PAN") - r.GetMediaTrackInfo_Value(dest, "D_PAN")) < 0.001
          and r.GetMediaTrackInfo_Value(tr, "B_MUTE") == r.GetMediaTrackInfo_Value(dest, "B_MUTE")
        local cabe = igual
        if cabe then
          for k = 0, nIt - 1 do
            local it = r.GetTrackMediaItem(tr, k)
            local p = r.GetMediaItemInfo_Value(it, "D_POSITION")
            if not trackLivre(dest, p, p + r.GetMediaItemInfo_Value(it, "D_LENGTH")) then cabe = false; break end
          end
        end
        if cabe then
          for k = nIt - 1, 0, -1 do r.MoveMediaItemToTrack(r.GetTrackMediaItem(tr, k), dest) end
          r.DeleteTrack(tr)
          fundidas = fundidas + 1
          movido = true
          break
        end
      end
    end
    if not movido then table.insert(destinos[chave], tr) end
    end
  end
  return fundidas
end
-- Corta o silencio do FIM de um item: o item termina onde o ultimo som termina.
-- So o fim e cortado (o inicio nao muda). Devolve o tamanho final do item.
local function cortarSilencioFinal(item)
  local LIMIAR_DB = -50   -- abaixo disso conta como silencio
  local FOLGA = 0.3       -- segundos mantidos depois do ultimo som
  local MINIMO = 0.5      -- o item nunca fica menor que isso
  local len = r.GetMediaItemInfo_Value(item, "D_LENGTH")
  local take = r.GetActiveTake(item)
  if not take or r.TakeIsMIDI(take) then return len end
  local src = r.GetMediaItemTake_Source(take)
  if not src then return len end
  local sr = r.GetMediaSourceSampleRate(src)
  if not sr or sr <= 0 then sr = 44100 end
  local nch = r.GetMediaSourceNumChannels(src)
  if not nch or nch < 1 then nch = 1 end
  if nch > 2 then nch = 2 end
  local acc = r.CreateTakeAudioAccessor(take)
  if not acc then return len end

  local lim = 10 ^ (LIMIAR_DB / 20)
  local bloco = 0.25
  local buf = r.new_array(math.floor(sr * bloco) * nch + nch)
  local ultimoSom = nil
  local fim = len
  while fim > 0.001 do
    local ini = fim - bloco
    if ini < 0 then ini = 0 end
    local qtd = math.floor((fim - ini) * sr)
    if qtd < 1 then break end
    buf.clear()
    local ok = r.GetAudioAccessorSamples(acc, sr, nch, ini, qtd, buf)
    if ok == 1 then
      -- de tras pra frente, 1 amostra a cada 3 (passo impar confere os dois canais)
      for i = qtd * nch, 1, -3 do
        local v = buf[i]
        if v and (v > lim or v < -lim) then
          ultimoSom = ini + math.floor((i - 1) / nch) / sr
          break
        end
      end
    end
    if ultimoSom then break end
    fim = ini
  end
  r.DestroyAudioAccessor(acc)

  if not ultimoSom then return len end          -- item todo mudo: deixa como esta
  local novo = ultimoSom + FOLGA
  if novo < MINIMO then novo = MINIMO end
  if novo >= len - 0.05 then return len end     -- quase nada a cortar
  r.SetMediaItemInfo_Value(item, "D_LENGTH", novo)
  return novo
end

-- importa todos os audios de uma pasta como UMA musica; devolve fim, qtd de arquivos
local function importarMusica(dir, nomeMusica, inicio)
  local arqs = listarAudios(dir)
  if #arqs == 0 then return nil, 0 end
  local base = dir:gsub("[/\\]$", "")
  local usados, maxLen, cont = {}, 0, 0
  for _, arq in ipairs(arqs) do
    local src = r.PCM_Source_CreateFromFile(base .. "/" .. arq)
    if src then
      local len = r.GetMediaSourceLength(src)
      local nome = limparNome(arq)
      local cat = identificar(nome)
      local nomeBase, n = nome, 2
      while usados[nome:lower()] do nome = nomeBase .. " " .. n; n = n + 1 end
      usados[nome:lower()] = true
      local tr = acharOuCriarTrack(nome, cat, inicio, inicio + len)
      local item = r.AddMediaItemToTrack(tr)
      local take = r.AddTakeToMediaItem(item)
      r.SetMediaItemTake_Source(take, src)
      r.SetMediaItemInfo_Value(item, "D_POSITION", inicio)
      r.SetMediaItemInfo_Value(item, "D_LENGTH", len)
      r.GetSetMediaItemTakeInfo_String(take, "P_NAME", nomeMusica .. " - " .. nome, true)
      local lenFinal = cortarSilencioFinal(item) or len
      if lenFinal > maxLen then maxLen = lenFinal end
      cont = cont + 1
    end
  end
  if cont == 0 then return nil, 0 end
  r.AddProjectMarker2(0, true, inicio, inicio + maxLen, nomeMusica, -1, 0)
  if CRIAR_MARCADOR_INICIO then
    r.AddProjectMarker2(0, false, inicio, 0, "IN\xC3\x8DCIO - " .. nomeMusica, -1, 0)
  end
  return inicio + maxLen, cont
end

-- (Plano B) Janela antiga: escolhe UMA pasta so. Usada se o SELECIONAR_PASTAS.ps1 nao for encontrado/falhar.
-- Devolve true + "pasta\*" (caminho ficticio dentro da pasta) ou false se cancelou.
local function escolherPastaUnica()
  local tmp = (os.getenv("TEMP") or ".") .. "\\vs_pasta.txt"
  local f0 = io.open(tmp, "wb")
  if f0 then f0:write(""); f0:close() end
  local ps = "Add-Type -AssemblyName System.Windows.Forms; " ..
    "$d = New-Object System.Windows.Forms.FolderBrowserDialog; " ..
    "$d.Description = 'Selecione a PASTA da musica (com os audios dentro)'; " ..
    "$d.ShowNewFolderButton = $false; " ..
    "$d.SelectedPath = [Environment]::GetFolderPath('MyDocuments'); " ..
    "$o = New-Object System.Windows.Forms.Form; $o.TopMost = $true; " ..
    "$p = ''; if ($d.ShowDialog($o) -eq 'OK') { $p = $d.SelectedPath }; " ..
    "[IO.File]::WriteAllText((Join-Path $env:TEMP 'vs_pasta.txt'), $p, (New-Object Text.UTF8Encoding($false)))"
  local ret = r.ExecProcess('powershell -NoProfile -STA -WindowStyle Hidden -Command "' .. ps .. '"', 0)
  local f = io.open(tmp, "rb")
  if f then
    local dir = f:read("*a") or ""
    f:close()
    dir = dir:gsub("^%s+", ""):gsub("%s+$", "")
    if dir ~= "" then return true, dir .. "\\*" end
    if ret ~= nil then return false, "" end
  end
  -- plano B: seletor de arquivo (escolha qualquer audio da pasta)
  local ultimo = r.GetExtState(EXT, "ultimo_arquivo")
  return r.GetUserFileNameForRead(ultimo, "Selecione QUALQUER \xC3\xA1udio da pasta da m\xC3\xBAsica", "")
end

-- Janela moderna do Windows onde da pra marcar VARIAS pastas de uma vez (Ctrl/Shift ou arrastando).
-- Devolve: lista de pastas ({} se cancelou) ou nil se nao deu pra abrir (ai usa o plano B).
local function achaScriptSelecionarPastas()
  local cands = {}
  local ok, src = pcall(function() return debug.getinfo(1, "S").source end)
  local d = ok and src and src:match("^@(.*[\\/])")
  if d then cands[#cands + 1] = d .. "SELECIONAR_PASTAS.ps1" end
  cands[#cands + 1] = r.GetResourcePath() .. "\\Scripts\\SELECIONAR_PASTAS.ps1"
  for _, c in ipairs(cands) do
    local f = io.open(c, "rb")
    if f then f:close(); return c end
  end
  return nil
end

local function escolherPastasMusica()
  local script = achaScriptSelecionarPastas()
  if not script then return nil end
  local saida = (os.getenv("TEMP") or ".") .. "\\vs_pastas.txt"
  local f0 = io.open(saida, "wb")
  if f0 then f0:write(""); f0:close() end
  local cmd = 'powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' .. script ..
    '" -saida "' .. saida .. '"'
  local inicial = (r.GetExtState(EXT, "ultima_pasta") or ""):gsub("[\\/]+$", "")
  if #inicial > 2 then cmd = cmd .. ' -inicial "' .. inicial .. '"' end
  r.ExecProcess(cmd, 0)
  local f = io.open(saida, "rb")
  if not f then return nil, "sem resposta do PowerShell" end
  local txt = f:read("*a") or ""
  f:close()
  txt = txt:gsub("^\xEF\xBB\xBF", "")
  local lista, ok = {}, false
  for linha in txt:gmatch("[^\r\n]+") do
    if linha:sub(1, 5) == "#ERRO" then return nil, linha:sub(7) end
    if linha == "#OK" then
      ok = true
    else
      linha = linha:gsub("^%s+", ""):gsub("%s+$", "")
      if linha ~= "" then lista[#lista + 1] = linha end
    end
  end
  -- sem a marca #OK o PowerShell nao chegou a abrir a janela: NAO e cancelamento
  if not ok then return nil, "o PowerShell n\xC3\xA3o abriu a janela" end
  return lista
end

-- ordem "natural": Musica 2 vem antes de Musica 10
local function chaveNatural(s)
  return (s:lower():gsub("%d+", function(n) return string.rep("0", 12 - #n) .. n end))
end
local function ordenarNatural(t)
  table.sort(t, function(a, b) return chaveNatural(a) < chaveNatural(b) end)
end


local campos, selecao, rolagem, alturaConteudo = nil, nil, 0, 0

local function detectarBpm(dir)
  for _, arq in ipairs(listarAudios(dir)) do
    if arq:lower():find("click", 1, true) then
      for n in arq:gmatch("%d+") do
        local v = tonumber(n)
        if v and v >= 40 and v <= 300 then return tostring(v) end
      end
    end
  end
  return tostring(math.floor(r.Master_GetTempo() + 0.5))
end

local function acaoSelecionarMusica()
  local escolhidas, motivo = escolherPastasMusica()
  if escolhidas == nil then
    -- plano B: seletor antigo (uma pasta so)
    local ok, arquivo = escolherPastaUnica()
    if not ok or not arquivo or arquivo == "" then
      if motivo then
        setStatus("Janela de v\xC3\xA1rias pastas falhou (" .. motivo .. "). Veja %APPDATA%\\VS_Estudio_Henzo\\pastas_erro.txt", "erro")
      else
        setStatus("Sele\xC3\xA7\xC3\xA3o cancelada.", "aviso")
      end
      return
    end
    local d = arquivo:match("^(.*)[/\\][^/\\]*$")
    if not d then setStatus("Caminho inv\xC3\xA1lido.", "erro"); return end
    escolhidas = { d }
  end
  if #escolhidas == 0 then setStatus("Sele\xC3\xA7\xC3\xA3o cancelada.", "aviso"); return end
  local paiEscolhida = escolhidas[1]:match("^(.*)[/\\][^/\\]*$")
  if paiEscolhida then r.SetExtState(EXT, "ultima_pasta", paiEscolhida, true) end

  local multi = #escolhidas > 1
  local pasta, vistas, semAudio = {}, {}, 0
  local function add(d)
    local k = d:lower():gsub("/", "\\")
    if not vistas[k] then vistas[k] = true; pasta[#pasta + 1] = d end
  end
  for _, dir in ipairs(escolhidas) do
    if #listarAudios(dir) > 0 then
      add(dir)
    else
      -- a pasta escolhida nao tem audio direto: procura musicas nas subpastas
      local achadas, k = {}, 0
      while true do
        local sub = r.EnumerateSubdirectories(dir, k)
        if not sub then break end
        local d = dir .. "/" .. sub
        if #listarAudios(d) > 0 then achadas[#achadas + 1] = d end
        k = k + 1
      end
      if #achadas == 0 then
        semAudio = semAudio + 1
      else
        ordenarNatural(achadas)
        if not multi and #achadas > 1 then
          local resp = r.MB("Essa pasta n\xC3\xA3o tem \xC3\xA1udios diretos, mas encontrei " .. #achadas ..
            " pastas de m\xC3\xBAsicas dentro dela.\n\nImportar TODAS?", "Importar m\xC3\xBAsicas", 4)
          if resp ~= 6 then setStatus("Importa\xC3\xA7\xC3\xA3o cancelada.", "aviso"); return end
        end
        for _, d in ipairs(achadas) do add(d) end
      end
    end
  end
  if #pasta == 0 then
    setStatus("Nenhum \xC3\xA1udio (mp3, wav, flac, aif, ogg, m4a) nas pastas escolhidas.", "erro")
    return
  end

  -- uma pasta so: se existem pastas irmas com musicas, oferece importar todas
  if not multi and #pasta == 1 then
    local dir = pasta[1]
    local pai = dir:match("^(.*)[/\\][^/\\]*$")
    if pai then
      local irmas, i = {}, 0
      while true do
        local sub = r.EnumerateSubdirectories(pai, i)
        if not sub then break end
        local d = pai .. "/" .. sub
        if #listarAudios(d) > 0 then irmas[#irmas + 1] = d end
        i = i + 1
      end
      if #irmas >= 2 then
        ordenarNatural(irmas)
        local nomeAtual = dir:match("([^/\\]+)$")
        local resp = r.MB("Encontrei " .. #irmas .. " pastas de m\xC3\xBAsicas em:\n" .. pai ..
          "\n\nSIM = importar TODAS (ordem alfab\xC3\xA9tica)\nN\xC3\x83O = importar s\xC3\xB3 \"" .. nomeAtual .. "\"",
          "Importar m\xC3\xBAsicas", 3)
        if resp == 2 then setStatus("Importa\xC3\xA7\xC3\xA3o cancelada.", "aviso"); return end
        if resp == 6 then pasta = irmas end
      end
    end
  end
  ordenarNatural(pasta)
  local qtdArqSel = 0
  for _, d in ipairs(pasta) do qtdArqSel = qtdArqSel + #listarAudios(d) end
  selecao = { pastas = pasta, qtd = qtdArqSel }
  campos.nome.texto = (#pasta == 1) and (pasta[1]:match("([^/\\]+)$") or "") or ""
  campos.bpm.texto = detectarBpm(pasta[1])
  rolagem = 0
  if #pasta == 1 then
    setStatus("Confira o nome e o BPM e clique em GERAR M\xC3\x9ASICA.", "aviso")
  else
    local t = #pasta .. " m\xC3\xBAsicas selecionadas. Clique em GERAR M\xC3\x9ASICA."
    if semAudio > 0 then t = t .. " (" .. semAudio .. " pasta(s) sem \xC3\xA1udio ignorada(s))" end
    setStatus(t, "aviso")
  end
end

local function acaoGerarMusica()
  if not selecao then setStatus("Selecione uma m\xC3\xBAsica primeiro.", "erro"); return end
  local pasta = selecao.pastas
  r.Undo_BeginBlock()
  r.PreventUIRefresh(1)
  local fim = fimDoProjeto()
  local inicio = (fim > 0) and (math.ceil(fim) + GAP_ENTRE_MUSICAS) or 0
  local primeiro = inicio
  local qtdMusicas, qtdArq, puladas = 0, 0, 0
  for _, d in ipairs(pasta) do
    local nomeMusica = d:match("([^/\\]+)$") or d
    if #pasta == 1 then
      local digitado = campos.nome.texto:gsub("^%s+", ""):gsub("%s+$", "")
      if digitado ~= "" then nomeMusica = digitado end
    end
    local bpmTxt = (#pasta == 1) and campos.bpm.texto or detectarBpm(d)
    local bpm = tonumber(((bpmTxt or ""):gsub(",", ".")))
    if bpm and bpm >= 20 and bpm <= 400 and not regiaoExiste(nomeMusica) then
      if inicio <= 0 then r.SetCurrentBPM(0, bpm, false)
      else r.SetTempoTimeSigMarker(0, -1, inicio, -1, -1, bpm, 0, 0, false) end
    end
    if regiaoExiste(nomeMusica) then
      puladas = puladas + 1
    else
      local novoFim, n = importarMusica(d, nomeMusica, inicio)
      if novoFim then
        qtdMusicas = qtdMusicas + 1
        qtdArq = qtdArq + n
        inicio = math.ceil(novoFim) + GAP_ENTRE_MUSICAS
      end
    end
  end
  r.PreventUIRefresh(-1)
  r.Undo_EndBlock("VS: importar m\xC3\xBAsicas", -1)
  r.SetEditCurPos(primeiro, true, false)
  r.UpdateArrange()
  r.TrackList_AdjustWindows(false)

  if qtdMusicas > 0 then
    selecao = nil
    campos.nome.foco = false; campos.bpm.foco = false
    local t = "\xC3\x81udios importados com sucesso! (" .. qtdMusicas .. " m\xC3\xBAsica(s), " .. qtdArq .. " arquivos)"
    if puladas > 0 then t = t .. " - " .. puladas .. " j\xC3\xA1 existia(m)" end
    setStatus(t, "ok")
  elseif puladas > 0 then
    setStatus("Essa m\xC3\xBAsica j\xC3\xA1 existe no projeto (region com o mesmo nome).", "aviso")
  else
    setStatus("Nenhum \xC3\xA1udio encontrado na pasta.", "erro")
  end
end

-- ------------------------------------------------------------
-- Editar track selecionada
-- ------------------------------------------------------------
local function acaoEditarTrack()
  local n = r.CountSelectedTracks(0)
  if n == 0 then setStatus("Selecione uma track primeiro.", "erro"); return end
  local tr1 = r.GetSelectedTrack(0, 0)
  local nomeAtual = nomeTrack(tr1)
  local catAtual = catDaTrack(tr1)
  local campoNome = (n == 1) and "Nome da track (vazio = manter):" or "Nome (ignorado com v\xC3\xA1rias tracks):"
  local ok, res = r.GetUserInputs("Editar track selecionada", 2,
    campoNome .. ",Instrumento (click, bateria, baixo, guitarra, teclado, metais, vocal, loop):",
    ((n == 1) and nomeAtual or "") .. "," .. catAtual.curto)
  if not ok then setStatus("Edi\xC3\xA7\xC3\xA3o cancelada.", "aviso"); return end
  local nomeNovo, instr = res:match("^(.*),([^,]*)$")
  if not nomeNovo then setStatus("Entrada inv\xC3\xA1lida.", "erro"); return end
  instr = instr:gsub("^%s+", ""):gsub("%s+$", "")
  nomeNovo = nomeNovo:gsub("^%s+", ""):gsub("%s+$", "")
  local cat
  if instr ~= "" then
    cat = catPorTexto(instr)
    if not cat then setStatus("Instrumento n\xC3\xA3o reconhecido: " .. instr, "erro"); return end
  end
  r.Undo_BeginBlock()
  for i = 0, n - 1 do
    local tr = r.GetSelectedTrack(0, i)
    if n == 1 and nomeNovo ~= "" then setNomeTrack(tr, nomeNovo) end
    local c = cat or identificar(nomeTrack(tr))
    setExt(tr, "vs_cat", c.id)
    r.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", nativeCor(c.cor))
  end
  r.Undo_EndBlock("VS: editar track", -1)
  r.TrackList_AdjustWindows(false)
  r.UpdateArrange()
  setStatus("Track editada: " .. (cat and cat.nome or "ok") .. (n > 1 and (" (" .. n .. " tracks)") or ""), "ok")
end

-- ------------------------------------------------------------
-- Reorganizar projeto (identifica, colore, ordena e cria pastas)
-- ------------------------------------------------------------
local function acaoReorganizar()
  if r.CountTracks(0) == 0 then setStatus("O projeto n\xC3\xA3o tem tracks.", "erro"); return end
  r.Undo_BeginBlock()
  r.PreventUIRefresh(1)

  for i = r.CountTracks(0) - 1, 0, -1 do
    local tr = r.GetTrack(0, i)
    if ehPasta(tr) then r.DeleteTrack(tr) end
  end

  local fundidas = consolidarTracks()

  local cortados = 0
  for i = 0, r.CountMediaItems(0) - 1 do
    local it = r.GetMediaItem(0, i)
    local antes = r.GetMediaItemInfo_Value(it, "D_LENGTH")
    local depois = cortarSilencioFinal(it)
    if depois < antes - 0.05 then cortados = cortados + 1 end
  end

  local lista = {}
  for i = 0, r.CountTracks(0) - 1 do
    local tr = r.GetTrack(0, i)
    r.SetMediaTrackInfo_Value(tr, "I_FOLDERDEPTH", 0)
    local cat = catDaTrack(tr)
    setExt(tr, "vs_cat", cat.id)
    r.SetMediaTrackInfo_Value(tr, "I_CUSTOMCOLOR", nativeCor(cat.cor))
    lista[#lista + 1] = { tr = tr, cat = cat, ord = i }
  end
  table.sort(lista, function(a, b)
    if a.cat.ordem ~= b.cat.ordem then return a.cat.ordem < b.cat.ordem end
    return a.ord < b.ord
  end)

  r.Main_OnCommand(40297, 0) -- desmarca todas as tracks
  for _, e in ipairs(lista) do
    r.SetOnlyTrackSelected(e.tr)
    r.ReorderSelectedTracks(r.CountTracks(0), 0)
  end

  local pastas = 0
  for ci = #CATS, 1, -1 do
    local c = CATS[ci]
    local membros = {}
    for _, e in ipairs(lista) do
      if e.cat.id == c.id then membros[#membros + 1] = e.tr end
    end
    -- pasta so quando a categoria tem 2 ou mais tracks; track unica fica solta (sem pasta repetida)
    if #membros > 1 then
      local idx = math.floor(r.GetMediaTrackInfo_Value(membros[1], "IP_TRACKNUMBER")) - 1
      r.InsertTrackAtIndex(idx, true)
      local pasta = r.GetTrack(0, idx)
      setNomeTrack(pasta, c.nome)
      setExt(pasta, "vs_folder", "1")
      setExt(pasta, "vs_cat", c.id)
      r.SetMediaTrackInfo_Value(pasta, "I_CUSTOMCOLOR", nativeCor(c.cor))
      r.SetMediaTrackInfo_Value(pasta, "I_FOLDERDEPTH", 1)
      r.SetMediaTrackInfo_Value(membros[#membros], "I_FOLDERDEPTH", -1)
      pastas = pastas + 1
    end
  end

  r.Main_OnCommand(40297, 0)
  r.PreventUIRefresh(-1)
  r.Undo_EndBlock("VS: reorganizar projeto", -1)
  r.TrackList_AdjustWindows(false)
  r.UpdateArrange()
  setStatus("Projeto reorganizado! " .. #lista .. " tracks, " .. pastas .. " pasta(s) (so onde ha mais de uma track do mesmo grupo)." .. ((fundidas > 0) and (" " .. fundidas .. " tracks iguais foram unidas.") or "") .. ((cortados > 0) and (" " .. cortados .. " itens tiveram o silencio do final cortado.") or ""), "ok")
end

-- ------------------------------------------------------------
-- Campos de texto (valores guardados entre as aberturas)
-- ------------------------------------------------------------
campos = {
  nome = { texto = "", foco = false, limpar = false, livre = true },
  lufs = { texto = (tonumber(r.GetExtState(EXT, "lufs")) ~= nil) and tostring(tonumber(r.GetExtState(EXT, "lufs"))) or tostring(LUFS_PADRAO), foco = false, limpar = false },
  bpm = { texto = "138", foco = false, limpar = false },
  tom = { texto = (r.GetExtState(EXT, "tom") ~= "" and r.GetExtState(EXT, "tom") or "0"), foco = false, limpar = false },
  db  = { texto = (r.GetExtState(EXT, "db") ~= "" and r.GetExtState(EXT, "db") or "-9"), foco = false, limpar = false },
}

-- ------------------------------------------------------------
-- Mudar tom
-- ------------------------------------------------------------
local function regiaoAtual()
  local pos
  if (r.GetPlayState() & 1) == 1 then pos = r.GetPlayPosition() else pos = r.GetCursorPosition() end
  local i = 0
  while true do
    local ret, isrgn, rs, re, nome = r.EnumProjectMarkers3(0, i)
    if ret == 0 then break end
    if isrgn and pos >= rs - 0.0005 and pos < re then return { ini = rs, fim = re, nome = nome } end
    i = i + 1
  end
  return nil
end

local function acaoMudarTom()
  local reg = regiaoAtual()
  if not reg then setStatus("Posicione o cursor dentro de uma m\xC3\xBAsica (region).", "erro"); return end
  local st = parseNum(campos.tom.texto)
  if not st then setStatus("Valor de semitons inv\xC3\xA1lido.", "erro"); return end
  r.SetExtState(EXT, "tom", campos.tom.texto, true)

  r.Undo_BeginBlock()
  local itens = 0
  for i = 0, r.CountMediaItems(0) - 1 do
    local it = r.GetMediaItem(0, i)
    local pos = r.GetMediaItemInfo_Value(it, "D_POSITION")
    if pos >= reg.ini - 0.001 and pos < reg.fim then
      local cat = catDaTrack(r.GetMediaItem_Track(it))
      if cat.transpor then
        local take = r.GetActiveTake(it)
        if take and not r.TakeIsMIDI(take) then
          r.SetMediaItemTakeInfo_Value(take, "D_PITCH", st)
          itens = itens + 1
        end
      end
    end
  end
  r.Undo_EndBlock("VS: mudar tom", -1)
  r.UpdateArrange()
  setStatus(string.format("Tom %+g semitons em \"%s\" (%d itens). Click, bateria e percuss\xC3\xA3o n\xC3\xA3o mudam.", st, reg.nome, itens), "ok")
end

-- ------------------------------------------------------------
-- Abaixar tracks (anti-clipping)
-- ------------------------------------------------------------
local function acaoAbaixar()
  local db = parseNum(campos.db.texto)
  if not db or db >= 0 then setStatus("Use um valor negativo em dB (ex: -9).", "erro"); return end
  r.SetExtState(EXT, "db", campos.db.texto, true)
  local fator = 10 ^ (db / 20)
  r.Undo_BeginBlock()
  local n = 0
  for i = 0, r.CountTracks(0) - 1 do
    local tr = r.GetTrack(0, i)
    if not ehPasta(tr) and r.GetMediaTrackInfo_Value(tr, "I_FOLDERDEPTH") ~= 1 then
      r.SetMediaTrackInfo_Value(tr, "D_VOL", r.GetMediaTrackInfo_Value(tr, "D_VOL") * fator)
      n = n + 1
    end
  end
  r.Undo_EndBlock("VS: abaixar tracks", -1)
  r.TrackList_AdjustWindows(false)
  r.UpdateArrange()
  if n == 0 then setStatus("Nenhuma track de instrumento encontrada.", "erro")
  else setStatus(string.format("%d tracks abaixadas em %g dB (pastas intactas).", n, db), "ok") end
end

-- ------------------------------------------------------------
-- Renderizar musicas (uma por region, normalizadas em LUFS)
-- ------------------------------------------------------------
local tela = "principal"
local render = {
  pasta = r.GetExtState(EXT, "render_pasta"),
  formato = tonumber(r.GetExtState(EXT, "render_formato")) or 1,
  todas = true,
}
local FORMATOS = {
  { nome = "WAV", b64 = "ZXZhdxgAAQ==" },
  { nome = "WAV 16 bits", b64 = "ZXZhdxAAAQ==" },
}
if not FORMATOS[render.formato] then render.formato = 1 end

local function listarRegioes()
  local lista, i = {}, 0
  while true do
    local ret, isrgn, rs, re, nome = r.EnumProjectMarkers3(0, i)
    if ret == 0 then break end
    if isrgn then lista[#lista + 1] = { ini = rs, fim = re, nome = nome } end
    i = i + 1
  end
  return lista
end

local function regioesParaRenderizar()
  if render.todas then return listarRegioes() end
  local reg = regiaoAtual()
  if reg then return { reg } end
  return {}
end

local function nomeArquivoSeguro(s)
  s = (s or ""):gsub('[<>:"/\\|%?%*]', "_"):gsub("^%s+", ""):gsub("%s+$", "")
  if s == "" then s = "Musica" end
  return s
end

local function escolherPastaDestino()
  local tmp = (os.getenv("TEMP") or ".") .. "\\vs_destino.txt"
  local f0 = io.open(tmp, "wb")
  if f0 then f0:write(""); f0:close() end
  local ps = "Add-Type -AssemblyName System.Windows.Forms; " ..
    "$d = New-Object System.Windows.Forms.FolderBrowserDialog; " ..
    "$d.Description = 'Escolha a pasta onde salvar as musicas renderizadas'; " ..
    "$d.ShowNewFolderButton = $true; " ..
    "$o = New-Object System.Windows.Forms.Form; $o.TopMost = $true; " ..
    "$p = ''; if ($d.ShowDialog($o) -eq 'OK') { $p = $d.SelectedPath }; " ..
    "[IO.File]::WriteAllText((Join-Path $env:TEMP 'vs_destino.txt'), $p, (New-Object Text.UTF8Encoding($false)))"
  r.ExecProcess('powershell -NoProfile -STA -WindowStyle Hidden -Command "' .. ps .. '"', 0)
  local f = io.open(tmp, "rb")
  if not f then return nil end
  local dir = f:read("*a") or ""
  f:close()
  dir = dir:gsub("^%s+", ""):gsub("%s+$", "")
  if dir == "" then return nil end
  return dir
end

local function acaoEscolherDestino()
  local d = escolherPastaDestino()
  if not d then setStatus("Nenhuma pasta escolhida.", "aviso"); return end
  render.pasta = d
  r.SetExtState(EXT, "render_pasta", d, true)
  setStatus("Pasta de destino definida.", "ok")
end

local function acaoRenderizar()
  if render.pasta == "" then setStatus("Escolha a pasta de destino primeiro.", "erro"); return end
  local lufs = parseNum(campos.lufs.texto)
  if not lufs or lufs >= 0 then setStatus("LUFS inv\xC3\xA1lido (use algo como -14).", "erro"); return end
  r.SetExtState(EXT, "lufs", tostring(lufs), true)
  local lista = regioesParaRenderizar()
  if #lista == 0 then
    setStatus(render.todas and "Nenhuma region encontrada. Importe m\xC3\xBAsicas primeiro."
      or "Posicione o cursor dentro de uma m\xC3\xBAsica (region).", "erro")
    return
  end
  r.RecursiveCreateDirectory(render.pasta, 0)

  -- guarda o mute das tracks e a selecao de tempo para devolver tudo como estava
  local nTr = r.CountTracks(0)
  local mutes, clicks, temClick = {}, {}, false
  for i = 0, nTr - 1 do
    local tr = r.GetTrack(0, i)
    mutes[i] = r.GetMediaTrackInfo_Value(tr, "B_MUTE")
    clicks[i] = (not ehPasta(tr)) and (catDaTrack(tr).id == "CLICK")
    if clicks[i] then temClick = true end
  end
  local ts, te = r.GetSet_LoopTimeRange(false, false, 0, 0, false)

  local function aplicarMute(somenteClick)
    for i = 0, nTr - 1 do
      local tr = r.GetTrack(0, i)
      if not ehPasta(tr) then
        local mudo = (mutes[i] == 1) or (clicks[i] ~= somenteClick)
        r.SetMediaTrackInfo_Value(tr, "B_MUTE", mudo and 1 or 0)
      end
    end
  end

  local fmt = FORMATOS[render.formato] or FORMATOS[1]
  r.GetSetProjectInfo_String(0, "RENDER_FILE", render.pasta, true)
  r.GetSetProjectInfo_String(0, "RENDER_FORMAT", fmt.b64, true)
  r.GetSetProjectInfo(0, "RENDER_SETTINGS", 0, true)
  r.GetSetProjectInfo(0, "RENDER_ADDTOPROJ", 0, true)

  local function passe(sufixo, canais, normalizar, somenteClick)
    aplicarMute(somenteClick)
    r.GetSetProjectInfo(0, "RENDER_CHANNELS", canais, true)
    r.GetSetProjectInfo(0, "RENDER_NORMALIZE", normalizar and 1 or 0, true)
    if normalizar then r.GetSetProjectInfo(0, "RENDER_NORMALIZE_TARGET", 10 ^ (lufs / 20), true) end
    if render.todas then
      r.GetSetProjectInfo(0, "RENDER_BOUNDSFLAG", 3, true)
      r.GetSetProjectInfo_String(0, "RENDER_PATTERN", "$region/" .. sufixo, true)
    else
      local reg = lista[1]
      r.GetSet_LoopTimeRange(true, false, reg.ini, reg.fim, false)
      r.GetSetProjectInfo(0, "RENDER_BOUNDSFLAG", 2, true)
      r.GetSetProjectInfo_String(0, "RENDER_PATTERN", nomeArquivoSeguro(reg.nome) .. "/" .. sufixo, true)
    end
    r.Main_OnCommand(42230, 0) -- renderiza com as configuracoes acima, sem janela
  end

  local ok, err = pcall(function()
    passe("VS", 2, true, false)
    if temClick then passe("CLICK E REGENCIA", 1, false, true) end
  end)

  for i = 0, nTr - 1 do
    r.SetMediaTrackInfo_Value(r.GetTrack(0, i), "B_MUTE", mutes[i])
  end
  r.GetSet_LoopTimeRange(true, false, ts, te, false)
  r.UpdateArrange()
  r.TrackList_AdjustWindows(false)

  if not ok then setStatus("Erro no render: " .. tostring(err), "erro"); return end
  tela = "principal"
  local msg = string.format("Render conclu\xC3\xADdo: %d m\xC3\xBAsica(s) a %g LUFS na pasta escolhida.", #lista, lufs)
  if not temClick then msg = msg .. " (nenhuma track de click/guia encontrada)" end
  setStatus(msg, temClick and "ok" or "aviso")
end
-- ------------------------------------------------------------
-- Interface (gfx nativo)
-- ------------------------------------------------------------
local clique, mouseAnt = false, false
local pendente, fase = nil, 0

-- Licenca: estado compartilhado (o restante do codigo da licenca fica mais abaixo)
local LIC = { estado = "verificando", plano = nil, expira = 0, chave = "", provisoria = false, aguardando = nil, ultVerif = 0 }
local campoChave = { texto = "", livre = true, foco = true, pos = 0, ini = 1 }
local licAtivar, licColar

local function agendar(fn)
  if pendente or LIC.estado ~= "ok" then return end
  pendente = fn
  fase = 0
  setStatus("Processando...", "ocupado")
end

local function cor(rr, gg, bb, a) gfx.set(rr, gg, bb, a or 1) end

local function texto(str, x, y, w, h, alinhar)
  local tw, th = gfx.measurestr(str)
  if alinhar == "c" then gfx.x = x + (w - tw) / 2 else gfx.x = x end
  gfx.y = y + (h - th) / 2
  gfx.drawstr(str)
  return tw
end

local function quebrar(str, larg)
  local linhas, atual = {}, ""
  for palavra in str:gmatch("%S+") do
    local t = (atual == "") and palavra or (atual .. " " .. palavra)
    if gfx.measurestr(t) > larg and atual ~= "" then
      linhas[#linhas + 1] = atual; atual = palavra
    else
      atual = t
    end
  end
  if atual ~= "" then linhas[#linhas + 1] = atual end
  return linhas
end

-- ---------- visual moderno: helpers ----------
local function lim(v) return math.max(0, math.min(1, v)) end
local function mix(a, b, t) return a + (b - a) * t end
local hov = {}   -- animacao suave do hover (por botao)

-- retangulo arredondado cheio (usa a cor atual de gfx.set)
local function arred(x, y, w, h, rd)
  x, y, w, h = math.floor(x), math.floor(y), math.floor(w), math.floor(h)
  rd = math.max(1, math.min(rd, math.floor(h / 2), math.floor(w / 2)))
  gfx.rect(x + rd, y, w - 2 * rd, h, 1)
  gfx.rect(x, y + rd, rd, h - 2 * rd, 1)
  gfx.rect(x + w - rd, y + rd, rd, h - 2 * rd, 1)
  gfx.circle(x + rd, y + rd, rd, 1, 1)
  gfx.circle(x + w - rd - 1, y + rd, rd, 1, 1)
  gfx.circle(x + rd, y + h - rd - 1, rd, 1, 1)
  gfx.circle(x + w - rd - 1, y + h - rd - 1, rd, 1, 1)
end

-- retangulo arredondado com degrade horizontal c1 -> c2 e brilho no topo
local function arredGrad(x, y, w, h, rd, c1, c2)
  x, y, w, h = math.floor(x), math.floor(y), math.floor(w), math.floor(h)
  gfx.set(c1[1], c1[2], c1[3], 1); arred(x, y, w, h, rd)
  gfx.set(c2[1], c2[2], c2[3], 1)
  gfx.rect(x + w - rd, y + rd, rd, h - 2 * rd, 1)
  gfx.circle(x + w - rd - 1, y + rd, rd, 1, 1)
  gfx.circle(x + w - rd - 1, y + h - rd - 1, rd, 1, 1)
  local gw = w - 2 * rd
  gfx.gradrect(x + rd, y, gw, h, c1[1], c1[2], c1[3], 1,
    (c2[1] - c1[1]) / gw, (c2[2] - c1[2]) / gw, (c2[3] - c1[3]) / gw, 0, 0, 0, 0, 0)
  local hh = math.floor(h / 2)
  gfx.gradrect(x + rd, y + 1, gw, hh, 1, 1, 1, 0.16, 0, 0, 0, 0, 0, 0, 0, -0.16 / hh)
end

-- ---------- icones modernos (selo colorido + animacao no hover) ----------
local ACENTO = {
  pasta      = { 1.00, 0.76, 0.25 },
  lapis      = { 1.00, 0.55, 0.28 },
  engrenagem = { 0.45, 0.80, 1.00 },
  doc        = { 0.72, 0.62, 1.00 },
  piano      = { 1.00, 0.50, 0.80 },
  som        = { 0.40, 0.95, 0.70 },
  x          = { 1.00, 0.35, 0.40 },
  foguete    = { 0.60, 0.55, 1.00 },
}

local function glifo(tipo, cx, cy, bg, hv, tm, ac)
  local cos, sin, fl = math.cos, math.sin, math.floor
  if tipo == "pasta" then
    gfx.set(ac[1] * 0.75, ac[2] * 0.75, ac[3] * 0.55, 1)
    gfx.rect(cx - 7, cy - 5, 14, 11, 1); gfx.rect(cx - 7, cy - 7, 6, 3, 1)
    local k = 2.5 * hv   -- a frente da pasta "abre" no hover
    gfx.set(1.0, 0.87, 0.45, 1)
    gfx.triangle(cx - 7, cy + 6, cx + 7, cy + 6, cx + 8 + k, cy - 2)
    gfx.triangle(cx - 7, cy + 6, cx + 8 + k, cy - 2, cx - 6 + k, cy - 2)

  elseif tipo == "lapis" then
    local a = -0.785 + sin(tm * 12) * 0.18 * hv   -- balanca no hover
    local ca, sa = cos(a), sin(a)
    local function pt(s, p) return cx + s * ca - p * sa, cy + s * sa + p * ca end
    local function quad(s1, s2, p1, p2)
      local x1, y1 = pt(s1, p1); local x2, y2 = pt(s2, p1)
      local x3, y3 = pt(s2, p2); local x4, y4 = pt(s1, p2)
      gfx.triangle(x1, y1, x2, y2, x3, y3); gfx.triangle(x1, y1, x3, y3, x4, y4)
    end
    gfx.set(ac[1], ac[2], ac[3], 1); quad(-3, 5, -2.2, 2.2)         -- corpo
    gfx.set(0.78, 0.8, 0.86, 1);     quad(4.6, 5.6, -2.2, 2.2)      -- virola
    gfx.set(1.0, 0.62, 0.72, 1);     quad(5.6, 8, -2.2, 2.2)        -- borracha
    gfx.set(1.0, 0.86, 0.62, 1)                                     -- madeira
    do
      local x1, y1 = pt(-3, -2.2); local x2, y2 = pt(-3, 2.2); local x3, y3 = pt(-7.8, 0)
      gfx.triangle(x1, y1, x2, y2, x3, y3)
    end
    gfx.set(0.18, 0.18, 0.24, 1)                                    -- grafite
    do
      local x1, y1 = pt(-6, -0.9); local x2, y2 = pt(-6, 0.9); local x3, y3 = pt(-7.8, 0)
      gfx.triangle(x1, y1, x2, y2, x3, y3)
    end
    if hv > 0.03 then                                               -- risco que aparece no hover
      gfx.set(ac[1], ac[2], ac[3], 0.9 * hv)
      local lx = fl(cx - 8)
      gfx.line(lx, fl(cy + 8), lx + 15 * hv, fl(cy + 8))
      gfx.line(lx, fl(cy + 9), lx + 15 * hv, fl(cy + 9))
    end

  elseif tipo == "engrenagem" then
    local ang = tm * (0.6 + 3.0 * hv)   -- sempre girando devagar, rapido no hover
    gfx.set(mix(0.78, ac[1], hv), mix(0.80, ac[2], hv), mix(0.86, ac[3], hv), 1)
    gfx.circle(cx, cy, 5.5, 1, 1)
    for i = 0, 7 do
      local a = ang + i * math.pi / 4
      local x1, y1 = cx + cos(a - 0.42) * 4.5, cy + sin(a - 0.42) * 4.5
      local x2, y2 = cx + cos(a + 0.42) * 4.5, cy + sin(a + 0.42) * 4.5
      local x3, y3 = cx + cos(a + 0.22) * 8, cy + sin(a + 0.22) * 8
      local x4, y4 = cx + cos(a - 0.22) * 8, cy + sin(a - 0.22) * 8
      gfx.triangle(x1, y1, x2, y2, x3, y3); gfx.triangle(x1, y1, x3, y3, x4, y4)
    end
    gfx.set(bg[1], bg[2], bg[3], 1); gfx.circle(cx, cy, 2.3, 1, 1)

  elseif tipo == "doc" then
    gfx.set(0.88, 0.88, 0.96, 1); gfx.rect(cx - 6, cy - 8, 12, 16, 1)
    gfx.set(bg[1], bg[2], bg[3], 1)                                 -- canto dobrado
    gfx.triangle(cx + 2, cy - 8, cx + 6, cy - 8, cx + 6, cy - 4)
    gfx.set(ac[1], ac[2], ac[3], 1)
    gfx.triangle(cx + 2, cy - 8, cx + 2, cy - 4, cx + 6, cy - 4)
    for i = 0, 2 do                                                 -- linhas crescem no hover
      local w = 6 + 2 * lim(hv * 3 - i * 0.8)
      gfx.set(mix(0.15, ac[1] * 0.7, hv), mix(0.14, ac[2] * 0.7, hv), mix(0.28, ac[3] * 0.7, hv), 1)
      gfx.rect(fl(cx - 4), fl(cy - 1 + i * 3), fl(w), 1, 1)
    end

  elseif tipo == "piano" then
    gfx.set(0.93, 0.93, 0.97, 1); gfx.rect(cx - 8, cy - 6, 16, 12, 1)
    gfx.set(0.6, 0.6, 0.7, 1)
    for i = 1, 3 do gfx.line(cx - 8 + i * 4, cy - 6, cx - 8 + i * 4, cy + 5) end
    for i = 1, 3 do                                                 -- teclas pretas "apertam" no hover
      local press = hv * (0.5 + 0.5 * sin(tm * 9 + i * 2.1))
      gfx.set(0.10, 0.10, 0.16, 1)
      gfx.rect(fl(cx - 8 + i * 4 - 1.5), cy - 6, 3, fl(7 - 2.5 * press), 1)
    end

  elseif tipo == "som" then
    gfx.set(0.92, 0.93, 0.97, 1)
    gfx.rect(cx - 8, cy - 3, 4, 6, 1)
    gfx.triangle(cx - 4, cy - 3, cx + 1, cy - 7, cx + 1, cy + 7)
    gfx.triangle(cx - 4, cy - 3, cx - 4, cy + 3, cx + 1, cy + 7)
    for i = 1, 3 do                                                 -- ondas pulsam no hover
      local al
      if i == 1 then al = 0.95
      elseif i == 2 then al = 0.45 + 0.5 * hv
      else al = hv * (0.5 + 0.5 * sin(tm * 8)) end
      if al > 0.02 then
        gfx.set(ac[1], ac[2], ac[3], al)
        local rad = 3 + i * 2.6
        local px, py
        for s = -4, 4 do
          local a = s * 0.2
          local qx, qy = cx + 1 + cos(a) * rad, cy + sin(a) * rad
          if px then gfx.line(px, py, qx, qy); gfx.line(px + 1, py, qx + 1, qy) end
          px, py = qx, qy
        end
      end
    end

  elseif tipo == "x" then
    local rot = hv * 0.6
    local L = 5.2 * (1 + 0.2 * hv)
    local ca, sa = cos(rot), sin(rot)
    local function pr(dx, dy) return cx + dx * ca - dy * sa, cy + dx * sa + dy * ca end
    gfx.set(ac[1], ac[2], ac[3], 1)
    for o = -1, 1 do
      local x1, y1 = pr(-L + o, -L); local x2, y2 = pr(L + o, L)
      gfx.line(x1, y1, x2, y2)
      x1, y1 = pr(L + o, -L); x2, y2 = pr(-L + o, L)
      gfx.line(x1, y1, x2, y2)
    end

  elseif tipo == "foguete" then
    local y0 = cy - 2 * hv + sin(tm * 3) * 0.6
    local len = 3.5 + 3 * hv + sin(tm * 25) * 1.2                   -- chama tremula e cresce no hover
    gfx.set(1.0, 0.60, 0.15, 1); gfx.triangle(cx - 2.5, y0 + 4, cx + 2.5, y0 + 4, cx, y0 + 4 + len)
    gfx.set(1.0, 0.92, 0.40, 1); gfx.triangle(cx - 1.2, y0 + 4, cx + 1.2, y0 + 4, cx, y0 + 4 + len * 0.6)
    gfx.set(ac[1], ac[2], ac[3], 1)
    gfx.triangle(cx - 3, y0, cx - 3, y0 + 5, cx - 7, y0 + 5)
    gfx.triangle(cx + 3, y0, cx + 3, y0 + 5, cx + 7, y0 + 5)
    gfx.set(0.95, 0.95, 1.0, 1); gfx.rect(cx - 3, y0 - 6, 6, 10, 1)
    gfx.set(ac[1], ac[2], ac[3], 1); gfx.triangle(cx - 3, y0 - 6, cx + 3, y0 - 6, cx, y0 - 11)
    gfx.set(0.20, 0.45, 0.90, 1); gfx.circle(cx, y0 - 2, 1.7, 1, 1)
  end
end

-- icone dentro de um "selo" arredondado colorido; hv = 0..1 (quanto o mouse esta em cima)
-- semBadge = true desenha so o desenho, sem o selo
local function icone(tipo, cx, cy, fundo, hv, semBadge)
  hv = hv or 0
  fundo = fundo or { 0.10, 0.12, 0.18 }
  local tm = r.time_precise()
  local ac = ACENTO[tipo] or { 0.8, 0.8, 0.9 }
  local bg = fundo
  if not semBadge then
    local x, y = math.floor(cx - 12), math.floor(cy - 12)
    if hv > 0.02 then
      for i = 1, 3 do
        gfx.set(ac[1], ac[2], ac[3], 0.20 * hv / i)
        gfx.roundrect(x - i, y - i, 24 + 2 * i - 1, 24 + 2 * i - 1, 8 + i, 1)
      end
    end
    gfx.set(ac[1], ac[2], ac[3], 0.40 + 0.45 * hv); arred(x, y, 24, 24, 7)
    local k = 0.16 + 0.12 * hv
    bg = { mix(fundo[1] * 0.6, ac[1], k), mix(fundo[2] * 0.6, ac[2], k), mix(fundo[3] * 0.6, ac[3], k) }
    gfx.set(bg[1], bg[2], bg[3], 1); arred(x + 1, y + 1, 22, 22, 6)
  end
  glifo(tipo, cx, cy, bg, hv, tm, ac)
end

local function hsv(h, sat, v)
  h = (h % 1) * 6
  local i = math.floor(h)
  local f = h - i
  local p, q, t = v * (1 - sat), v * (1 - sat * f), v * (1 - sat * (1 - f))
  local k = i % 6
  if k == 0 then return v, t, p
  elseif k == 1 then return q, v, p
  elseif k == 2 then return p, v, t
  elseif k == 3 then return p, q, v
  elseif k == 4 then return t, p, v
  else return v, p, q end
end

-- faixa de marca no topo: luz neon (ciano -> azul -> roxo -> rosa) que flui;
-- corre mais rapido e pulsa quando o programa esta trabalhando; o mouse acende um ponto de luz nela
local function faixaTopo(W)
  local tm = r.time_precise()
  local ocupado = (status.tipo == "ocupado")
  local vel = ocupado and 0.9 or 0.18
  local pulso = ocupado and (0.8 + 0.2 * math.sin(tm * 8)) or 1
  local mx, my = gfx.mouse_x, gfx.mouse_y
  local perto = (my >= 0 and my < 70) and 1 or 0
  local passo = 6
  for x = 0, W - 1, passo do
    local fase = 0.5 + 0.5 * math.sin(6.2832 * (x / W - tm * vel))
    local rr, gg, bb = hsv(0.50 + 0.45 * fase, 0.85, 1)
    local luz = 0
    if perto == 1 then
      local d = math.abs((x + passo / 2) - mx)
      if d < 90 then luz = (1 - d / 90) ^ 2 * 0.6 end
    end
    rr, gg, bb = rr + (1 - rr) * luz, gg + (1 - gg) * luz, bb + (1 - bb) * luz
    gfx.set(rr, gg, bb, pulso)
    gfx.rect(x, 0, passo, 4, 1)
    gfx.set(rr, gg, bb, 0.22 * pulso)           -- brilho que escorre abaixo da faixa
    gfx.rect(x, 4, passo, 1, 1)
    gfx.set(rr, gg, bb, 0.10 * pulso)
    gfx.rect(x, 5, passo, 2, 1)
  end
end

local function fundoGeral()
  local W, H = gfx.w, gfx.h
  gfx.gradrect(0, 0, W, H, 0.040, 0.050, 0.085, 1, 0, 0, 0, 0, 0.040 / H, 0.018 / H, 0.065 / H, 0)
  faixaTopo(W)
end

local function barraSecao(x, y)
  gfx.gradrect(x - 2, y + 2, 3, 15, 0.2, 0.8, 1.0, 1, 0, 0, 0, 0, 0.35 / 15, -0.55 / 15, -0.05 / 15, 0)
end

local function botao(rotulo, ic, x, y, w, h, primario)
  local mx, my = gfx.mouse_x, gfx.mouse_y
  local sobre = mx >= x and mx < x + w and my >= y and my < y + h
  local apertado = sobre and ((gfx.mouse_cap & 1) == 1)
  local hv = hov[rotulo] or 0
  hv = hv + ((sobre and 1 or 0) - hv) * 0.3
  hov[rotulo] = hv
  local rd = 8
  local fundoIc
  if primario then
    for i = 1, 3 do
      gfx.set(0.45, 0.35, 1.0, (0.12 + 0.16 * hv) / i)
      gfx.roundrect(x - i, y - i, w + 2 * i - 1, h + 2 * i - 1, rd + i, 1)
    end
    local k = apertado and -0.09 or 0.08 * hv
    local c1 = { lim(0.08 + k), lim(0.50 + k), lim(1.00 + k) }
    local c2 = { lim(0.55 + k), lim(0.25 + k), lim(0.95 + k) }
    arredGrad(x, y, w, h, rd, c1, c2)
    fundoIc = c1
  else
    local bd = { mix(0.20, 0.20, hv), mix(0.26, 0.75, hv), mix(0.38, 1.0, hv) }
    local fd = { mix(0.105, 0.14, hv), mix(0.135, 0.19, hv), mix(0.20, 0.29, hv) }
    if apertado then fd = { 0.07, 0.09, 0.14 } end
    if hv > 0.02 then
      gfx.set(0.2, 0.75, 1.0, 0.22 * hv)
      gfx.roundrect(x - 1, y - 1, w + 1, h + 1, rd + 1, 1)
    end
    gfx.set(bd[1], bd[2], bd[3], 1); arred(x, y, w, h, rd)
    gfx.set(fd[1], fd[2], fd[3], 1); arred(x + 1, y + 1, w - 2, h - 2, rd - 1)
    fundoIc = fd
  end
  gfx.setfont(2)
  cor(1, 1, 1)
  local tw = gfx.measurestr(rotulo)
  local tx = x + (w - tw) / 2
  if hv > 0.04 then   -- brilho que corre pelo botao
    local bwid = 46
    local bx = x + ((r.time_precise() * 0.9) % 1.6 - 0.3) * w
    for i = 0, bwid - 1 do
      local px = math.floor(bx + i)
      if px >= x + rd and px < x + w - rd then
        gfx.set(1, 1, 1, 0.13 * hv * (1 - math.abs(i - bwid / 2) / (bwid / 2)))
        gfx.rect(px, y + 2, 1, h - 4, 1)
      end
    end
  end
  if ic then icone(ic, tx - 21, y + h / 2, fundoIc, hv) end
  cor(1, 1, 1)
  gfx.x = tx; gfx.y = y + (h - 15) / 2 - 1
  gfx.drawstr(rotulo)
  return sobre and clique
end

local function charsDe(s)
  local tb = {}
  for ch in s:gmatch("[\0-\127\194-\244][\128-\191]*") do tb[#tb + 1] = ch end
  return tb
end

-- troca o texto do campo e poe o cursor (pos = quantos caracteres ficam antes dele)
local function setTexto(c, novo, pos)
  c.texto = novo
  c.ultTxt = novo
  c.pos = pos
  c.tpisca = r.time_precise()
end

local function campo(c, x, y, w, h)
  local mx, my = gfx.mouse_x, gfx.mouse_y
  local sobre = mx >= x and mx < x + w and my >= y and my < y + h
  local cs = charsDe(c.texto)
  if c.ultTxt ~= c.texto then   -- o texto mudou de fora (ex.: escolheu uma pasta)
    c.ultTxt = c.texto; c.pos = #cs; c.ini = 1
  end
  c.pos = math.max(0, math.min(c.pos or #cs, #cs))
  c.ini = math.max(1, math.min(c.ini or 1, c.pos + 1))
  gfx.setfont(1)
  local larg = w - 16

  if clique then
    c.foco = sobre
    if sobre then
      c.limpar = (c.livre ~= true)
      c.tpisca = r.time_precise()
      -- o cursor vai para o ponto onde o mouse clicou
      local alvo = mx - (x + 8)
      local p, antes = c.ini - 1, 0
      for i = c.ini, #cs do
        local ate = gfx.measurestr(table.concat(cs, "", c.ini, i))
        if alvo < (antes + ate) / 2 then break end
        antes = ate
        p = i
      end
      c.pos = p
    end
  end

  -- rola o texto para o cursor ficar sempre visivel
  while c.ini > 1 and gfx.measurestr(table.concat(cs, "", c.ini - 1)) <= larg - 2 do c.ini = c.ini - 1 end
  while c.ini <= c.pos and gfx.measurestr(table.concat(cs, "", c.ini, c.pos)) > larg - 2 do c.ini = c.ini + 1 end
  local fim = c.ini - 1
  for i = c.ini, #cs do
    if gfx.measurestr(table.concat(cs, "", c.ini, i)) > larg then break end
    fim = i
  end

  local bd = c.foco and { 0.2, 0.75, 1.0 } or (sobre and { 0.30, 0.40, 0.58 } or { 0.20, 0.26, 0.38 })
  if c.foco then gfx.set(0.2, 0.75, 1.0, 0.28); gfx.roundrect(x - 1, y - 1, w + 1, h + 1, 7, 1) end
  gfx.set(bd[1], bd[2], bd[3], 1); arred(x, y, w, h, 6)
  gfx.set(0.065, 0.085, 0.135, 1); arred(x + 1, y + 1, w - 2, h - 2, 5)
  gfx.setfont(1)
  cor(1, 1, 1)
  texto(table.concat(cs, "", c.ini, fim), x + 8, y, larg, h, "l")
  if c.foco and ((r.time_precise() - (c.tpisca or 0)) % 1.0) < 0.55 then
    local cx = x + 8 + gfx.measurestr(table.concat(cs, "", c.ini, c.pos))
    local _, th = gfx.measurestr("Ag")
    cor(1, 1, 1)
    gfx.line(cx, y + (h - th) / 2, cx, y + (h + th) / 2)
  end
end

local function desenharStatus(x, y, w)
  local t = status.tipo
  local ic = { ok = { 0.2, 0.75, 0.35 }, erro = { 0.85, 0.25, 0.25 }, aviso = { 0.9, 0.7, 0.2 }, ocupado = { 0.2, 0.55, 1.0 } }
  local c = ic[t] or ic.ok
  gfx.setfont(1)
  local linhas = quebrar("Status: " .. status.texto, w - 44)
  local ph = math.max(30, #linhas * 18 + 12)
  gfx.set(0.16, 0.20, 0.30, 1); arred(x, y - 2, w, ph, 8)
  gfx.set(0.065, 0.085, 0.135, 1); arred(x + 1, y - 1, w - 2, ph - 2, 7)
  local cy = y - 2 + ph / 2
  gfx.set(c[1], c[2], c[3], 0.25); gfx.circle(x + 18, cy, 11, 1, 1)
  gfx.set(c[1], c[2], c[3], 1); gfx.circle(x + 18, cy, 8, 1, 1)
  cor(1, 1, 1)
  if t == "ok" then
    gfx.line(x + 14, cy, x + 17, cy + 3); gfx.line(x + 14, cy + 1, x + 17, cy + 4)
    gfx.line(x + 17, cy + 3, x + 22, cy - 4); gfx.line(x + 17, cy + 4, x + 22, cy - 3)
  else
    gfx.rect(x + 17, cy - 5, 2, 6, 1); gfx.rect(x + 17, cy + 3, 2, 2, 1)
  end
  cor(0.82, 0.86, 0.94)
  for i, l in ipairs(linhas) do
    gfx.x = x + 38; gfx.y = y + 4 + (i - 1) * 18
    gfx.drawstr(l)
  end
end

local function desenhar()
  local W = gfx.w
  local m = 8
  local bw = W - 2 * m
  fundoGeral()

  local mw = gfx.mouse_wheel
  if mw ~= 0 then rolagem = rolagem - mw * 0.4; gfx.mouse_wheel = 0 end
  local maxR = math.max(0, alturaConteudo - gfx.h)
  if rolagem > maxR then rolagem = maxR end
  if rolagem < 0 then rolagem = 0 end

  gfx.setfont(2)
  do
    local tm = r.time_precise()
    local sobreT = (gfx.mouse_y >= 6 and gfx.mouse_y < 34) and 1 or 0
    tituloVel = (tituloVel or 0.35) + ((sobreT == 1 and 1.6 or 0.35) - (tituloVel or 0.35)) * 0.12
    tituloFase = (tituloFase or 0) + tituloVel * 0.033
    local txt = "PKVS STUDIO"
    local letras = {}
    for ch in txt:gmatch(".") do letras[#letras + 1] = ch end
    local sp, total = 4, 0
    for _, ch in ipairs(letras) do total = total + gfx.measurestr(ch) + sp end
    total = total - sp
    local _, th = gfx.measurestr("A")
    local lx = (W - total) / 2
    for i, ch in ipairs(letras) do
      local fase = 0.5 + 0.5 * math.sin(6.2832 * (i / #letras * 0.9 - tituloFase))
      local rr, gg, bb = hsv(0.50 + 0.45 * fase, 0.55, 1)
      gfx.set(rr, gg, bb, 1)
      gfx.x = lx; gfx.y = 8 - rolagem + (22 - th) / 2 + 1
      gfx.drawstr(ch)
      lx = lx + gfx.measurestr(ch) + sp
    end
  end

  local y = 40 - rolagem
  if botao("SELECIONAR M\xC3\x9ASICA", "pasta", m, y, bw, 40, true) then agendar(acaoSelecionarMusica) end
  y = y + 52

  if selecao then
    gfx.setfont(2); cor(0.2, 0.85, 0.9)
    gfx.x = m + 2; gfx.y = y - 4; gfx.drawstr("CONFIRMA\xC3\x87\xC3\x83O")
    y = y + 22
    campo(campos.nome, m, y, bw - 190, 28)
    gfx.setfont(1); cor(0.9, 0.9, 0.95)
    gfx.x = m + bw - 180; gfx.y = y + 6
    gfx.drawstr((#selecao.pastas == 1) and "Nome da M\xC3\xBAsica" or "Nome (1 m\xC3\xBAsica)")
    y = y + 34
    campo(campos.bpm, m, y, bw - 190, 28)
    gfx.setfont(1); cor(0.9, 0.9, 0.95)
    gfx.x = m + bw - 180; gfx.y = y + 6
    gfx.drawstr("BPM")
    y = y + 36
    icone("pasta", m + 10, y + 9, { 0.105, 0.115, 0.145 }, 0, true)
    gfx.setfont(1); cor(0.25, 0.9, 0.35)
    gfx.x = m + 26; gfx.y = y
    gfx.drawstr("Arquivos Selecionados: " .. selecao.qtd .. " faixas")
    y = y + 28
    if botao("GERAR M\xC3\x9ASICA", "foguete", m, y, bw, 40, true) then agendar(acaoGerarMusica) end
    y = y + 52
  end
  gfx.set(0.16, 0.20, 0.30, 1); gfx.line(m, y - 6, m + bw, y - 6)
  if botao("EDITAR TRACK SELECIONADA", "lapis", m, y, bw, 36) then agendar(acaoEditarTrack) end
  y = y + 44
  if botao("REORGANIZAR PROJETO", "engrenagem", m, y, bw, 36) then agendar(acaoReorganizar) end
  y = y + 44
  if botao("RENDERIZAR M\xC3\x9ASICAS", "doc", m, y, bw, 36) then tela = "render"; setStatus("Escolha a pasta de destino e clique em RENDERIZAR.", "aviso") end
  y = y + 52

  -- MUDAR TOM
  barraSecao(m + 2, y); gfx.setfont(2); cor(0.96, 0.6, 0.15)
  gfx.x = m + 10; gfx.y = y; gfx.drawstr("MUDAR TOM")
  y = y + 22
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  local reg = regiaoAtual()
  gfx.x = m + 2; gfx.y = y
  gfx.drawstr("M\xC3\xBAsica Atual: " .. (reg and reg.nome or "Nenhuma Region selecionada"))
  y = y + 24
  campo(campos.tom, m, y, bw - 190, 28)
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  gfx.x = m + bw - 180; gfx.y = y + 6
  gfx.drawstr("Semitons (ex: -2 ou 1)")
  y = y + 36
  if botao("MUDAR TOM", "piano", m, y, bw, 36) then agendar(acaoMudarTom) end
  y = y + 52

  -- ABAIXAR TRACKS
  barraSecao(m + 2, y); gfx.setfont(2); cor(0.96, 0.6, 0.15)
  gfx.x = m + 10; gfx.y = y; gfx.drawstr("ABAIXAR TRACKS (ANTI-CLIPPING)")
  y = y + 22
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  local desc = "Baixa TODAS as tracks de instrumento por igual (pastas n\xC3\xA3o s\xC3\xA3o afetadas), pra tirar clipping sem mexer no equil\xC3\xADbrio da mixagem. O nivelamento de volume entre m\xC3\xBAsicas fica pro Render, em LUFS."
  for _, l in ipairs(quebrar(desc, bw - 4)) do
    gfx.x = m + 2; gfx.y = y; gfx.drawstr(l)
    y = y + 18
  end
  y = y + 8
  campo(campos.db, m, y, bw - 190, 28)
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  gfx.x = m + bw - 180; gfx.y = y + 6
  gfx.drawstr("dB (ex: -9)")
  y = y + 36
  if botao("ABAIXAR TRACKS", "som", m, y, bw, 36) then agendar(acaoAbaixar) end
  y = y + 48

  gfx.set(0.16, 0.20, 0.30, 1); gfx.line(m, y - 6, m + bw, y - 6)
  desenharStatus(m, y, bw)
  alturaConteudo = y + rolagem + 60
end

local function encurtar(str, larg)
  if gfx.measurestr(str) <= larg then return str end
  while #str > 8 and gfx.measurestr("..." .. str) > larg do
    str = str:sub((utf8.offset(str, 2)) or 2)
  end
  return "..." .. str
end

local function desenharRender()
  local W = gfx.w
  local m = 8
  local bw = W - 2 * m
  local fundo = { 0.105, 0.115, 0.145 }
  fundoGeral()

  icone("doc", m + 12, 22, fundo, 0, true)
  gfx.setfont(2); cor(0.96, 0.76, 0.18)
  gfx.x = m + 36; gfx.y = 13; gfx.drawstr("RENDERIZAR M\xC3\x9ASICAS")

  local y = 44
  if botao("ESCOLHER PASTA DE DESTINO", "pasta", m, y, bw, 40) then agendar(acaoEscolherDestino) end
  y = y + 50

  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  local rot = "Pasta: "
  local larg = bw - 4 - gfx.measurestr(rot)
  gfx.x = m + 2; gfx.y = y
  gfx.drawstr(rot .. ((render.pasta ~= "") and encurtar(render.pasta, larg) or "(nenhuma escolhida)"))
  y = y + 26

  -- formato (lista)
  local fw = bw - 190
  local mx, my = gfx.mouse_x, gfx.mouse_y
  local sobre = mx >= m and mx < m + fw and my >= y and my < y + 28
  cor(0.16, 0.22, 0.33); gfx.rect(m, y, fw, 28, 1)
  cor(1, 1, 1); gfx.setfont(1)
  texto((FORMATOS[render.formato] or FORMATOS[1]).nome, m + 8, y, fw - 40, 28, "l")
  cor(0.9, 0.9, 0.95); gfx.rect(m + fw - 28, y + 2, 26, 24, 1)
  cor(0.1, 0.1, 0.15); gfx.triangle(m + fw - 21, y + 10, m + fw - 9, y + 10, m + fw - 15, y + 18)
  if clique and sobre then
    gfx.x = m; gfx.y = y + 28
    local esc = gfx.showmenu("WAV|WAV 16 bits")
    if esc and esc > 0 then
      render.formato = esc
      r.SetExtState(EXT, "render_formato", tostring(esc), true)
    end
  end
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  gfx.x = m + bw - 180; gfx.y = y + 6
  gfx.drawstr("Formato")
  y = y + 36

  -- LUFS
  campo(campos.lufs, m, y, fw, 28)
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  gfx.x = m + bw - 180; gfx.y = y + 6
  gfx.drawstr("LUFS-I alvo")
  y = y + 40

  gfx.set(0.16, 0.20, 0.30, 1); gfx.line(m, y - 6, m + bw, y - 6)

  -- caixa de selecao: todas as musicas
  local sobreCx = mx >= m and mx < m + 300 and my >= y and my < y + 24
  if clique and sobreCx then render.todas = not render.todas end
  if render.todas then
    cor(0.10, 0.55, 1.0); gfx.rect(m + 2, y + 2, 20, 20, 1)
    cor(1, 1, 1)
    for o = 0, 1 do
      gfx.line(m + 6, y + 12 + o, m + 10, y + 16 + o)
      gfx.line(m + 10, y + 16 + o, m + 18, y + 7 + o)
    end
  else
    cor(0.16, 0.22, 0.33); gfx.rect(m + 2, y + 2, 20, 20, 1)
    cor(0.5, 0.55, 0.65); gfx.rect(m + 2, y + 2, 20, 20, 0)
  end
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  gfx.x = m + 32; gfx.y = y + 4
  gfx.drawstr("Renderizar TODAS as m\xC3\xBAsicas")
  y = y + 34

  local lista = regioesParaRenderizar()
  local aviso
  if render.todas then
    aviso = #lista .. " m\xC3\xBAsica(s) na timeline ser\xC3\xA3o renderizadas."
  elseif #lista == 1 then
    aviso = "Ser\xC3\xA1 renderizada s\xC3\xB3 a m\xC3\xBAsica sob o cursor: " .. lista[1].nome
  else
    aviso = "Posicione o cursor dentro de uma m\xC3\xBAsica (region)."
  end
  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  for _, l in ipairs(quebrar(aviso, bw - 4)) do
    gfx.x = m + 2; gfx.y = y; gfx.drawstr(l); y = y + 18
  end
  y = y + 8
  gfx.set(0.16, 0.20, 0.30, 1); gfx.line(m, y - 4, m + bw, y - 4)
  y = y + 6

  gfx.setfont(1); cor(0.9, 0.9, 0.95)
  for _, l in ipairs(quebrar("Cada m\xC3\xBAsica gera 2 arquivos: 'CLICK E REGENCIA' (mono) e 'VS' (est\xC3\xA9reo L/R).", bw - 4)) do
    gfx.x = m + 2; gfx.y = y; gfx.drawstr(l); y = y + 18
  end
  y = y + 10
  gfx.set(0.16, 0.20, 0.30, 1); gfx.line(m, y - 4, m + bw, y - 4)
  y = y + 6

  if botao("RENDERIZAR", "foguete", m, y, bw, 40, true) then agendar(acaoRenderizar) end
  y = y + 48
  if botao("CANCELAR", "x", m, y, bw, 36) then
    tela = "principal"
    setStatus("Render cancelado.", "aviso")
  end
  y = y + 48
  gfx.set(0.16, 0.20, 0.30, 1); gfx.line(m, y - 6, m + bw, y - 6)
  desenharStatus(m, y, bw)
end

local function processarTeclas()
  local ch = gfx.getchar()
  while ch ~= 0 do
    if ch == -1 then return false end
    local c = nil
    if LIC.estado ~= "ok" then
      c = campoChave; c.foco = true
    else
      for _, k in ipairs({ "nome", "bpm", "tom", "db", "lufs" }) do
        if campos[k].foco then c = campos[k]; break end
      end
    end
    if c then
      local cs = charsDe(c.texto)
      local pos = math.max(0, math.min(c.pos or #cs, #cs))
      if ch == 8 then
        if pos > 0 then table.remove(cs, pos); setTexto(c, table.concat(cs), pos - 1) end
        c.limpar = false
      elseif ch == 6579564 then                -- Delete
        if pos < #cs then table.remove(cs, pos + 1); setTexto(c, table.concat(cs), pos) end
        c.limpar = false
      elseif ch == 1818584692 then             -- seta esquerda
        c.pos = math.max(0, pos - 1); c.tpisca = r.time_precise(); c.limpar = false
      elseif ch == 1919379572 then             -- seta direita
        c.pos = math.min(#cs, pos + 1); c.tpisca = r.time_precise(); c.limpar = false
      elseif ch == 1752132965 then             -- Home
        c.pos = 0; c.tpisca = r.time_precise(); c.limpar = false
      elseif ch == 6647396 then                -- End
        c.pos = #cs; c.tpisca = r.time_precise(); c.limpar = false
      elseif ch == 13 then
        c.foco = false
        if c == campoChave then licAtivar()
        elseif c == campos.tom then agendar(acaoMudarTom)
        elseif c == campos.db then agendar(acaoAbaixar) end
      elseif ch == 27 then
        c.foco = false
      elseif ch == 22 and c == campoChave then
        licColar()
      elseif c.livre then
        if ch >= 32 and ch ~= 127 and ch < 65536 and #c.texto < 120 then
          local okc, sc = pcall(utf8.char, ch)
          if okc then table.insert(cs, pos + 1, sc); setTexto(c, table.concat(cs), pos + 1) end
        end
      elseif ch >= 32 and ch <= 126 then
        local s = string.char(ch)
        local padrao = (c == campos.bpm) and "[%d%.,]" or "[%d%-%+%.,]"
        if s:match(padrao) then
          if c.limpar then cs = {}; pos = 0; c.limpar = false end
          if #cs < 8 then table.insert(cs, pos + 1, s); setTexto(c, table.concat(cs), pos + 1) end
        end
      end
    elseif ch == 32 then
      r.Main_OnCommand(40044, 0) -- espaco = play/stop
    end
    ch = gfx.getchar()
  end
  return true
end

-- ------------------------------------------------------------
-- Bolinha flutuante PK
-- A bolinha e um programinha separado (BOLINHA.ps1) que este script abre
-- sozinho. Clique na bolinha = abre o painel; clique de novo (X) = fecha.
-- Conversa por arquivos na pasta %APPDATA%\VS_Estudio_Henzo.
-- ------------------------------------------------------------
local PW, PH = 490, 640
local DADOS = (os.getenv("APPDATA") or ".") .. "\\VS_Estudio_Henzo\\"
r.RecursiveCreateDirectory(DADOS, 0)
local ARQ_CMD, ARQ_ESTADO, ARQ_BOLINHA = DADOS .. "cmd.txt", DADOS .. "estado.txt", DADOS .. "bolinha.txt"

local function lerArquivo(caminho)
  local f = io.open(caminho, "rb")
  if not f then return nil end
  local t = f:read("*a")
  f:close()
  return t
end
local function escreverArquivo(caminho, t)
  local f = io.open(caminho, "wb")
  if f then f:write(t); f:close() end
end

local aberto, ocupado = false, false
local function gravarEstado()
  escreverArquivo(ARQ_ESTADO, (aberto and "aberto" or "fechado") .. "|" .. os.time() .. "|" .. (ocupado and "1" or "0"))
end

local function pastaDoScript()
  local ok, src = pcall(function() return debug.getinfo(1, "S").source end)
  if ok and src then
    local d = src:match("^@(.*[\\/])")
    if d then return d end
  end
  return nil
end

local function bolinhaViva()
  local t = lerArquivo(ARQ_BOLINHA)
  local ts = t and tonumber(t:match("(%d+)"))
  return ts ~= nil and (os.time() - ts) <= 6
end

local function iniciarBolinha()
  local cands = {}
  local d = pastaDoScript()
  if d then cands[#cands + 1] = d .. "BOLINHA.ps1" end
  cands[#cands + 1] = r.GetResourcePath() .. "\\Scripts\\BOLINHA.ps1"
  for _, c in ipairs(cands) do
    local f = io.open(c, "rb")
    if f then
      f:close()
      r.ExecProcess('powershell -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "' .. c .. '"', -1)
      return true
    end
  end
  return false
end

-- ------------------------------------------------------------
-- Licenca (key do cliente)
-- A key fica em %APPDATA%\VS_Estudio_Henzo\licenca.dat. A conferencia com o
-- servidor e feita pelo LICENCA.ps1, em segundo plano (nao trava o REAPER).
-- Sem internet: continua funcionando ate DIAS_OFFLINE dias depois da ultima conferencia.
-- ------------------------------------------------------------
local DIAS_OFFLINE  = 7
local REVERIFICAR_S = 6 * 3600
local ESPERA_RESP_S = 30
local ARQ_LIC, ARQ_LIC_RESP = DADOS .. "licenca.dat", DADOS .. "licenca_resp.txt"
local NOMES_PLANO = { mensal = "Mensal", ["6meses"] = "6 meses", anual = "Anual" }
local MSG_RECUSA = {
  invalida        = "Key inválida. Confira se copiou certinho, sem faltar nenhum pedaço.",
  revogada        = "Esta key foi cancelada.",
  outro_pc        = "Esta key já está em uso em outro computador. Cada key vale para 1 computador.",
  expirada        = "Sua key expirou. Renove o plano e cole a nova key.",
  dados_invalidos = "Não foi possível validar a key. Tente de novo.",
}

local function limparChave(t)
  t = tostring(t or ""):upper():gsub("[^A-Z0-9%-]", "")
  return t:sub(1, 40)
end

local function licLerCache()
  local t = lerArquivo(ARQ_LIC)
  if not t then return nil end
  local c = {}
  for k, v in t:gmatch("([%w_]+)=([^\r\n]*)") do c[k] = v end
  if not c.chave or c.chave == "" then return nil end
  c.expira = tonumber(c.expira) or 0
  c.ultimo_ok = tonumber(c.ultimo_ok)
  return c
end

local function licGravarCache(c)
  escreverArquivo(ARQ_LIC, string.format("chave=%s\nplano=%s\nexpira=%.0f\nultimo_ok=%d\nmaquina=%s\n",
    c.chave, c.plano or "", c.expira or 0, c.ultimo_ok or 0, c.maquina or ""))
end

local function licDias()
  if not LIC.expira or LIC.expira <= 0 then return 0 end
  return math.max(0, math.ceil((LIC.expira / 1000 - os.time()) / 86400))
end

local function licAcharArquivo(nome)
  local cands = {}
  local d = pastaDoScript()
  if d then cands[#cands + 1] = d .. nome end
  cands[#cands + 1] = r.GetResourcePath() .. "\\Scripts\\" .. nome
  for _, c in ipairs(cands) do
    local f = io.open(c, "rb")
    if f then f:close(); return c end
  end
  return nil
end

local function licBloquear(msg, motivo)
  LIC.estado, LIC.provisoria, LIC.motivo = "bloqueado", false, motivo
  setStatus(msg, "erro")
end

-- manda o LICENCA.ps1 consultar o servidor, sem esperar (a resposta vem por arquivo)
local function licIniciarVerificacao(chave, manual)
  local ps1 = licAcharArquivo("LICENCA.ps1")
  if not ps1 then
    licBloquear("Arquivo LICENCA.ps1 não encontrado. Extraia o ZIP inteiro e abra o INICIAR de novo.", "sem_arquivo")
    return
  end
  os.remove(ARQ_LIC_RESP)
  LIC.chaveVerif, LIC.manual = chave, manual
  LIC.aguardando = os.time() + ESPERA_RESP_S
  LIC.ultVerif = os.time()
  if manual then setStatus("Verificando sua key...", "ocupado") end
  r.ExecProcess('powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' .. ps1 ..
    '" -Chave "' .. chave .. '"', -1)
end

local function licLerResposta()
  local t = lerArquivo(ARQ_LIC_RESP)
  if not t or not t:find("resultado=", 1, true) then return nil end
  local R = {}
  for k, v in t:gmatch("([%w_]+)=([^\r\n]*)") do R[k] = v end
  if not R.resultado then return nil end
  return R
end

local function licAplicar(R)
  local agora = os.time()
  local manual = LIC.manual
  local antes = LIC.estado
  local chave = LIC.chaveVerif or LIC.chave
  LIC.aguardando, LIC.manual = nil, nil

  if R.resultado == "ok" then
    local expira = tonumber(R.expira_em) or 0
    LIC.estado, LIC.provisoria, LIC.motivo = "ok", false, nil
    LIC.chave, LIC.plano, LIC.expira = chave, R.plano, expira
    licGravarCache({ chave = chave, plano = R.plano, expira = expira, ultimo_ok = agora, maquina = R.maquina })
    if manual then campoChave.texto = ""; setTexto(campoChave, "", 0) end
    local nome = NOMES_PLANO[R.plano or ""] or tostring(R.plano or "")
    setStatus("Licença ativa. Plano " .. nome .. ", " .. licDias() .. " dia(s) restante(s).", "ok")

  elseif R.resultado == "recusada" then
    local motivo = R.motivo or "invalida"
    licBloquear(MSG_RECUSA[motivo] or MSG_RECUSA.invalida, motivo)
    if motivo ~= "expirada" then os.remove(ARQ_LIC) end   -- expirada: guarda a key para mostrar o aviso certo

  else   -- sem internet / servidor fora do ar / erro ao rodar o LICENCA.ps1
    local c = licLerCache()
    local mesma = c ~= nil and c.chave == chave
    local dentro = mesma and c.ultimo_ok ~= nil and (agora - c.ultimo_ok) >= -3600
      and (agora - c.ultimo_ok) <= DIAS_OFFLINE * 86400 and (c.expira or 0) > agora * 1000
    local mesmoPc = mesma and (not R.maquina or R.maquina == "" or c.maquina == R.maquina)
    if dentro and mesmoPc then
      LIC.estado, LIC.provisoria, LIC.motivo = "ok", true, nil
      LIC.chave, LIC.plano, LIC.expira = c.chave, c.plano, c.expira
      if manual or antes ~= "ok" then
        setStatus("Sem conexão com o servidor agora. Funcionando offline; conecte à internet em até " .. DIAS_OFFLINE .. " dias da última verificação.", "aviso")
      end
    elseif dentro and not mesmoPc then
      licBloquear("Esta licença foi ativada em outro computador.", "outro_pc")
    elseif manual or not mesma then
      LIC.estado = "semkey"
      setStatus("Não consegui falar com o servidor. Confira sua internet e tente de novo.", "erro")
    else
      licBloquear("Não consegui verificar sua licença. Conecte-se à internet e abra o painel de novo.", "sem_internet")
    end
  end
end

-- chamada a cada ciclo do loop: le a resposta, confere vencimento e reconfere de tempos em tempos
local function licTick()
  local agora = os.time()
  if LIC.aguardando then
    local R = licLerResposta()
    if R then
      os.remove(ARQ_LIC_RESP)
      licAplicar(R)
    elseif agora > LIC.aguardando then
      licAplicar({ resultado = "rede", maquina = "" })
    end
  end
  if LIC.estado == "ok" and (LIC.expira or 0) > 0 and agora * 1000 >= LIC.expira then
    licBloquear(MSG_RECUSA.expirada, "expirada")
  end
  if LIC.estado == "ok" and not LIC.aguardando and LIC.chave ~= "" and (agora - (LIC.ultVerif or 0)) > REVERIFICAR_S then
    licIniciarVerificacao(LIC.chave, false)
  end
end

local function licIniciar()
  local c = licLerCache()
  if c then
    local agora = os.time()
    LIC.chave, LIC.plano, LIC.expira = c.chave, c.plano, c.expira or 0
    local dentro = c.ultimo_ok ~= nil and (agora - c.ultimo_ok) >= -3600 and (agora - c.ultimo_ok) <= DIAS_OFFLINE * 86400
    if dentro and LIC.expira > agora * 1000 then
      LIC.estado, LIC.provisoria = "ok", true      -- libera ja; o servidor confirma em segundo plano
    else
      LIC.estado = "verificando"
    end
    setStatus("Verificando sua licença...", "ocupado")
    licIniciarVerificacao(c.chave, false)
  else
    LIC.estado = "semkey"
    setStatus("Cole sua key para ativar o PKVS Studio.", "aviso")
  end
end

licAtivar = function()
  if LIC.aguardando then return end
  local chave = limparChave(campoChave.texto)
  if #chave < 8 then
    setStatus("Cole ou digite sua key no campo acima.", "aviso")
    return
  end
  licIniciarVerificacao(chave, true)
end

licColar = function()
  local ret = r.ExecProcess('powershell -NoProfile -STA -WindowStyle Hidden -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Clipboard]::GetText()"', 5000)
  local t = ret and ret:match("^[^\n]*\n(.*)$") or ""
  t = limparChave(t)
  if t == "" then
    setStatus("Não achei uma key copiada. Copie a key e clique em COLAR KEY (ou use Ctrl+V).", "aviso")
    return
  end
  setTexto(campoChave, t, #charsDe(t))
  setStatus("Key colada. Clique em ATIVAR.", "ok")
end

local function desenharLicenca()
  local W = gfx.w
  local m = 12
  local bw = W - 2 * m
  fundoGeral()
  gfx.setfont(2); cor(0.55, 0.85, 1)
  texto("PKVS STUDIO", 0, 14, W, 22, "c")
  cor(1, 1, 1)
  texto("Ativar licença", 0, 52, W, 22, "c")
  gfx.setfont(1); cor(0.72, 0.78, 0.9)
  local y = 92
  local intro = (LIC.estado == "verificando") and "Verificando sua licença, aguarde um instante..."
    or "Cole abaixo a key que apareceu na tela depois do pagamento. Cada key vale para 1 computador."
  for _, l in ipairs(quebrar(intro, bw)) do
    gfx.x = m; gfx.y = y; gfx.drawstr(l); y = y + 20
  end
  y = y + 12
  if LIC.estado ~= "verificando" and not LIC.aguardando then
    barraSecao(m, y)
    gfx.setfont(2); cor(0.2, 0.85, 0.9)
    gfx.x = m + 8; gfx.y = y; gfx.drawstr("SUA KEY")
    y = y + 26
    campo(campoChave, m, y, bw, 34)
    y = y + 46
    if botao("COLAR KEY", nil, m, y, bw / 2 - 4, 38) then licColar() end
    if botao("ATIVAR", nil, m + bw / 2 + 4, y, bw / 2 - 4, 38, true) then licAtivar() end
    y = y + 54
  end
  desenharStatus(m, y, bw)
end

-- selo no canto: plano e dias restantes
local function desenharSelo()
  local d = licDias()
  local plano = NOMES_PLANO[LIC.plano or ""] or tostring(LIC.plano or "")
  local t = plano .. " · " .. d .. (d == 1 and " dia" or " dias") .. (LIC.provisoria and " (offline)" or "")
  gfx.setfont(1)
  if d <= 7 then cor(1, 0.8, 0.3) else cor(0.55, 0.85, 0.7) end
  local tw = gfx.measurestr(t)
  local yy = 10
  if tela ~= "render" then yy = 10 - rolagem end
  gfx.x = gfx.w - tw - 10; gfx.y = yy
  gfx.drawstr(t)
end

local function abrirPainel(px, py)
  if aberto then return end
  gfx.init(TITULO_JANELA, PW, PH, 0, px or 100, py or 80)
  gfx.setfont(1, "Segoe UI", 15)
  gfx.setfont(2, "Segoe UI", 15, string.byte("b"))
  aberto = true
  mouseAnt = true   -- evita clique "fantasma" ao abrir
  gravarEstado()
end

local function fecharPainel()
  if not aberto then return end
  gfx.quit()
  aberto = false
  gravarEstado()
end

r.atexit(function()
  if aberto then gfx.quit() end
  escreverArquivo(ARQ_ESTADO, "encerrado|" .. os.time() .. "|0")
end)

local function processarComandos()
  local t = lerArquivo(ARQ_CMD)
  if not t or t == "" then return true end
  os.remove(ARQ_CMD)
  local cmd, a, b = t:match("^%s*(%a+)|?(-?%d*)|?(-?%d*)")
  if cmd == "sair" then return false end
  if cmd == "fechar" then fecharPainel() end
  if cmd == "abrir" or cmd == "toggle" then
    if aberto then fecharPainel() else abrirPainel(tonumber(a), tonumber(b)) end
  end
  return true
end

-- partida: abre a bolinha (se ainda nao existir)
gravarEstado()
local esperaBolinha = nil
if not bolinhaViva() then
  if iniciarBolinha() then
    esperaBolinha = r.time_precise() + 10
  else
    setStatus("Arquivo BOLINHA.ps1 nao encontrado. Painel aberto normalmente.", "aviso")
    abrirPainel(100, 80)
  end
end

licIniciar()
if LIC.estado == "semkey" and not aberto then abrirPainel(100, 80) end

local ultEstado, ultCmd = 0, 0

local function loop()
  local agora = r.time_precise()
  r.SetExtState(EXT, "vivo", tostring(os.time()), false)
  licTick()

  if agora - ultEstado > 0.4 then ultEstado = agora; gravarEstado() end
  if agora - ultCmd > 0.1 then
    ultCmd = agora
    if not processarComandos() then return end
  end

  if esperaBolinha then
    if bolinhaViva() then
      esperaBolinha = nil
    elseif agora > esperaBolinha then
      esperaBolinha = nil
      setStatus("Nao consegui abrir a bolinha. Painel aberto normalmente.", "aviso")
      abrirPainel(100, 80)
    end
  end

  if aberto then
    local baixo = (gfx.mouse_cap & 1) == 1
    clique = baixo and not mouseAnt
    mouseAnt = baixo

    if not processarTeclas() then
      fecharPainel()          -- fechou pelo X da janela: volta a ser so a bolinha
    else
      if LIC.estado ~= "ok" then desenharLicenca()
      elseif tela == "render" then desenharRender() else desenhar() end
      if LIC.estado == "ok" then desenharSelo() end
      gfx.update()
    end
  end

  if pendente and aberto then
    if fase < 1 then
      fase = fase + 1
    else
      local f = pendente
      pendente = nil
      fase = 0
      ocupado = true; gravarEstado()
      local ok, err = pcall(f)
      ocupado = false; gravarEstado()
      if not ok then setStatus("Erro: " .. tostring(err), "erro") end
    end
  end
  r.defer(loop)
end

loop()
