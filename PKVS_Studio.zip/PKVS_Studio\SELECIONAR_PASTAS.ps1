﻿# PKVS Studio - seletor de VARIAS pastas de uma vez
# Abre a janela moderna do Windows (a mesma do Explorer). Use Ctrl ou Shift para marcar varias pastas.
# Grava o caminho de cada pasta escolhida, uma por linha, no arquivo informado em -saida.
param([string]$saida, [string]$inicial = '')
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class PKVSPastas
{
  [ComImport, Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]
  private class FileOpenDialogCom { }

  [ComImport, Guid("D57C7288-D4AD-4768-BE02-9D969532D960"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  private interface IFileOpenDialog
  {
    [PreserveSig] int Show(IntPtr hwndOwner);
    void SetFileTypes(uint n, IntPtr spec);
    void SetFileTypeIndex(uint i);
    void GetFileTypeIndex(out uint i);
    void Advise(IntPtr pfde, out uint cookie);
    void Unadvise(uint cookie);
    void SetOptions(uint fos);
    void GetOptions(out uint fos);
    void SetDefaultFolder(IShellItem psi);
    void SetFolder(IShellItem psi);
    void GetFolder(out IShellItem psi);
    void GetCurrentSelection(out IShellItem psi);
    void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string name);
    void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string name);
    void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string title);
    void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string text);
    void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string label);
    void GetResult(out IShellItem psi);
    void AddPlace(IShellItem psi, int fdap);
    void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string ext);
    void Close(int hr);
    void SetClientGuid(ref Guid guid);
    void ClearClientData();
    void SetFilter(IntPtr filter);
    void GetResults(out IShellItemArray items);
    void GetSelectedItems(out IShellItemArray items);
  }

  [ComImport, Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  private interface IShellItem
  {
    void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);
    void GetParent(out IShellItem psi);
    void GetDisplayName(uint sigdn, out IntPtr name);
    void GetAttributes(uint mask, out uint attribs);
    void Compare(IShellItem psi, uint hint, out int order);
  }

  [ComImport, Guid("B63EA76D-1F85-456F-A19C-48159EFA858B"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  private interface IShellItemArray
  {
    void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppvOut);
    void GetPropertyStore(int flags, ref Guid riid, out IntPtr ppv);
    void GetPropertyDescriptionList(IntPtr keyType, ref Guid riid, out IntPtr ppv);
    void GetAttributes(int attribFlags, uint mask, out uint attribs);
    void GetCount(out uint count);
    void GetItemAt(uint index, out IShellItem item);
    void EnumItems(out IntPtr enumShellItems);
  }

  [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
  private static extern void SHCreateItemFromParsingName(string path, IntPtr pbc, ref Guid riid, out IShellItem item);

  public static string[] Escolher(IntPtr dono, string titulo, string inicial)
  {
    IFileOpenDialog dlg = (IFileOpenDialog)new FileOpenDialogCom();
    uint opts;
    dlg.GetOptions(out opts);
    // PICKFOLDERS | FORCEFILESYSTEM | ALLOWMULTISELECT | PATHMUSTEXIST
    dlg.SetOptions(opts | 0x20u | 0x40u | 0x200u | 0x800u);
    dlg.SetTitle(titulo);
    dlg.SetOkButtonLabel("Selecionar pastas");
    if (!string.IsNullOrEmpty(inicial) && System.IO.Directory.Exists(inicial))
    {
      try
      {
        Guid g = new Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE");
        IShellItem it;
        SHCreateItemFromParsingName(inicial, IntPtr.Zero, ref g, out it);
        dlg.SetFolder(it);
      }
      catch { }
    }
    int hr = dlg.Show(dono);
    if (hr == unchecked((int)0x800704C7)) return new string[0];   // cancelou
    if (hr != 0) Marshal.ThrowExceptionForHR(hr);

    IShellItemArray arr;
    dlg.GetResults(out arr);
    uint n;
    arr.GetCount(out n);
    List<string> lista = new List<string>();
    for (uint i = 0; i < n; i++)
    {
      IShellItem it;
      arr.GetItemAt(i, out it);
      IntPtr p;
      it.GetDisplayName(0x80058000u, out p);   // SIGDN_FILESYSPATH
      string s = Marshal.PtrToStringUni(p);
      Marshal.FreeCoTaskMem(p);
      if (!string.IsNullOrEmpty(s)) lista.Add(s);
    }
    return lista.ToArray();
  }
}
'@

  # janela dona invisivel, sempre por cima, para o seletor nao ficar escondido atras do REAPER
  $dono = New-Object System.Windows.Forms.Form
  $dono.TopMost = $true
  $dono.ShowInTaskbar = $false
  $dono.FormBorderStyle = 'None'
  $dono.StartPosition = 'CenterScreen'
  $dono.Size = New-Object System.Drawing.Size(1, 1)
  $dono.Opacity = 0
  $dono.Show()
  $dono.Activate()
  try {
    $sel = [PKVSPastas]::Escolher($dono.Handle, 'Selecione as PASTAS das músicas (Ctrl ou Shift para marcar várias)', $inicial)
  } finally {
    $dono.Close()
  }
  [IO.File]::WriteAllText($saida, ('#OK' + "`r`n" + (@($sel) -join "`r`n")), $utf8)
} catch {
  $msg = ($_.Exception.Message -replace '[\r\n]+', ' ')
  try {
    $dados = Join-Path $env:APPDATA 'VS_Estudio_Henzo'
    New-Item -ItemType Directory -Force -Path $dados | Out-Null
    [IO.File]::WriteAllText((Join-Path $dados 'pastas_erro.txt'), ((Get-Date).ToString() + "`r`n" + ($_ | Out-String)), $utf8)
  } catch { }
  try { [IO.File]::WriteAllText($saida, ('#ERRO ' + $msg), $utf8) } catch { }
}
